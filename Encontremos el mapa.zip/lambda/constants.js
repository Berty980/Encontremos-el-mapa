module.exports = {
        PERSISTENT_ATTRIBUTES_NAMES: [
        // General
        'sessionCounter',
        // Pairs
        'pairsLevel', 'pairsLeft', 'pairsDoc', 'pairsTries', 'pairsEnd', 'lastCard1', 'lastCard2',
        'card1', 'card2', 'card3', 'card4', 'card5', 'card6', 'card7', 'card8', 'card9', 'card10',
        'card11', 'card12', 'card13', 'card14', 'card15', 'card16', 'card17', 'card18', 'card19', 'card20',
        'color1', 'color2', 'color3', 'color4', 'color5', 'color6', 'color7', 'color8', 'color9', 'color10', 
        'color11', 'color12', 'color13', 'color14', 'color15', 'color16', 'color17', 'color18', 'color19', 'color20',
        // Sports
        //'guessed', 'bestStreak',
        // Finding the map
        'phase', 'sightseeingPlayers', 'disableButtons',
        // Images minigame
        'imagesTurn', 'imagesCorrect', 'imagesOpacity',
        'imagesFrameColor1', 'imagesFrameColor2', 'imagesFrameColor3', 'imagesFrameColor4',
        // Labyrinth minigame
        'labTurn', 'moves', 'questions', 'onQuestion', 'readQuestion', 'questionOpacity', 'labEnded',
        'labTopP1', 'labLeftP1','labTopP2', 'labLeftP2','labTopP3', 'labLeftP3','labTopP4', 'labLeftP4',
        'avatarOpacity', 'mapOpacity', 'monument1Opacity', 'monument2Opacity', 'monument3Opacity', 'monument4Opacity',
        'labBorderOp1', 'labBorderOp2', 'labBorderOp3', 'labBorderOp4', 'labP1end', 'labP2end', 'labP3end', 'labP4end',
        'p1BorderColor', 'p2BorderColor', 'p3BorderColor', 'p4BorderColor',
        'searchEndOpacity',
        // Sayings minigame
        'sayingsTurn', 'saying1', 'saying2', 'sayingsOpacity', 'sayingsAvatarOpacity',
        'squareLeft1', 'squareLeft2', 'squareLeft3', 'squareLeft4', 'squareLeft5',
        'squareRight1', 'squareRight2', 'squareRight3', 'squareRight4', 'squareRight5',
        // Puzzle minigame
        'puzzleCorrect', 'puzzleTurn',
        'puzzleImOp1', 'puzzleImOp2', 'puzzleImOp3', 'puzzleImOp4', 'puzzleImOp5', 'puzzleImOp6', 'puzzleImOp7', 'puzzleImOp8',
        'puzzlePlOp1', 'puzzlePlOp2', 'puzzlePlOp3', 'puzzlePlOp4', 'puzzlePlOp5', 'puzzlePlOp6', 'puzzlePlOp7', 'puzzlePlOp8',
    ],
    APL: {
        askNameDoc: require('./documents/askName.json'),
        welcomeDoc: require('./documents/welcome.json'),
        catalogDoc: require('./documents/catalog.json'),
        loadGameDoc: require('./documents/pairs/loadGame.json'),
        pairsLevelDoc: require('./documents/pairs/pairsLevel.json'),
        pairsEasyDoc: require('./documents/pairs/pairsEasy.json'),
        pairsMediumDoc: require('./documents/pairs/pairsMedium.json'),
        pairsHardDoc: require('./documents/pairs/pairsHard.json'),
        sportsDoc: require('./documents/sports/sports.json'),
        choosePlayersDoc: require('./documents/sightseeing/choosePlayers.json'),
        launchDoc: require('./documents/sightseeing/sightseeing.json'),
        sayingsDoc: require('./documents/sightseeing/sayingsScreen.json'),
        imagesDoc: require('./documents/sightseeing/imagesScreen.json'),
        labDoc: require('./documents/sightseeing/labScreen.json'),
        parkDoc: require('./documents/sightseeing/parkScreen.json'),
        puzzleDoc: require('./documents/sightseeing/puzzleScreen.json'),
        finDoc: require('./documents/sightseeing/sightseeing.json')
    }
}
/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const AWS = require("aws-sdk");
const constants = require('./constants'); // constants such as specific service permissions go here
const Util = require('./util');
const interceptors = require('./interceptors');

const ddbAdapter = require('ask-sdk-dynamodb-persistence-adapter');

const ddbPersistenceAdapter = new ddbAdapter.DynamoDbPersistenceAdapter({
    tableName: process.env.DYNAMODB_PERSISTENCE_TABLE_NAME,
    createTable: false,
    dynamoDBClient: new AWS.DynamoDB({apiVersion: 'latest', region: process.env.DYNAMODB_PERSISTENCE_REGION})
});

let debug = "Debug: ";
let nextPlayer = [];

// What part of the map is filled by each piece
const pieces = ["1","2","3","4","5","6","7","8"];
const places = ["8","2","7","1","4","5","3","6"];

// SayingsPairs
let sayingsStartOrder = [];
let sayingsEndOrder = [];
let sayings = [];
let sayingsText = [];

// Laberinth possible moves from each cell: 0001 left, 0010 right, 0100 up, 1000 down
const laberinth = [["1000", "0000", "0000", "0010", "1011", "0011", "1001", "0000", "1010", "0011", "0011", "1001", "0010", "0011","1001", "1000"],
                   ["1100", "0000", "0000", "0000", "1110", "0011", "1101", "1010", "1101", "1000", "1000", "1110", "0011", "1001","1100", "1100"],
                   ["0110", "0011", "0011", "0011", "0101", "1000", "1100", "0100", "1100", "1100", "1100", "0110", "1001", "0110","0101", "1100"],
                   ["1010", "0011", "0011", "0011", "1011", "0101", "1100", "1000", "1100", "0110", "0111", "1001", "0110", "0011","0011", "0101"],
                   ["1100", "0000", "0000", "1000", "1100", "1010", "0101", "0110", "0101", "1000", "0000", "0110", "0011", "1001","1010", "0001"],
                   ["1110", "0011", "0011", "0101", "1100", "1100", "1000", "1010", "1011", "0101", "1010", "0011", "0011", "0101","0110", "1001"],
                   ["1100", "0000", "0000", "0000", "1100", "0110", "0101", "1100", "1100", "0000", "1100", "0000", "0000", "0000","1010", "0101"],
                   ["0100", "0000", "0000", "0000", "0110", "0011", "0011", "0101", "0100", "0000", "0110", "0011", "0011", "0011","0111", "0001"]];
                   
const labCellHeight = 8
const labCellWidth = 4.9
                    
const labFinalPos = [["47.4vw", "65vh"],
                     ["62.1vw", "57vh"],
                     ["52.3vw", "49vh"],
                     ["62.1vw", "33vh"]];

const halfSecondPause = "";
const oneSecondPause = "";
const oneAndHalfSecondPause = "";
const twoSecondsPause = "";
const oneMinuteOfSilence = "";
const eightySecondsPause = "";

// const halfSecondPause = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/0_5-seconds-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";
// const oneSecondPause = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/1-second-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";
// const oneAndHalfSecondPause = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/1_5-seconds-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";
// const twoSecondsPause = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/2-seconds-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";
// const oneMinuteOfSilence = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/1-minute-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";
// const eightySecondsPause = " <audio src=" + '"' + Util.getS3PreSignedUrl("Media/80-seconds-of-silence.mp3").replace(/&/g, '&amp;') + '"' + "/> ";

const colors = ["blue", "green", "orange", "purple", "red", "yellow", "black", "brown", "pink", "grey"];

let sportsInfo = [];

// Función que asigna aleatoriamente el color a las cartas del juego Encontrar las parejas
function randomColors(sessionAttributes, numPairs) {
    for (let i = 0; i < numPairs/2; i++) {
        for (let j = 0; j < 2; j++){
            let card = Math.floor(Math.random() * numPairs) + 1;
            if(!sessionAttributes["color" + card]) {
                sessionAttributes["color" + card] = colors[i];
            } else {
                j--;
            }
        }
    }
}

// Función que ordena aleatoriamente los deportes y las opciones de cada turno para el juego Adivinar el deporte
function randomSports(sports) {
    sportsInfo = [];
    const numSports = sports.length;
    for (let i = 0; i < numSports*2; i++) {
        let ret_aux = [0,0,0,0,"",""];
        let sport = Math.floor(Math.random() * numSports);
        ret_aux[0] = sport;
        let numImages = sports[sport][2].length;
        let image = sports[sport][2][Math.floor(Math.random() * numImages)];
        ret_aux[4] = image;
        let spots = [0,1,2];
        let index = Math.floor(Math.random() * 3);
        ret_aux[index+1] = sport;
        ret_aux[5] = sports[sport][1];
        spots.splice(index, 1);
        for (let j = 0; j < 3; j++){
            sport = Math.floor(Math.random() * numSports);
            if(ret_aux.includes(sport)) {
                j--;
            } else {
                index = Math.floor(Math.random() * 3);
                if(spots.length === 1) {
                    ret_aux[spots[0]+1] = sport;
                } else if(spots.includes(index)) {
                    ret_aux[index+1] = sport;
                    spots.splice(index, 1);
                } else {
                    j--;
                }
            }
        }
        sportsInfo.push(ret_aux);
    }
}

// Función que ordena aleatoriamente los refranes para el minijuego de unir refranes del juego Encontremos el mapa
function randomSayings(handlerInput) {
    sayingsStartOrder = [];
    sayingsEndOrder = [];
    sayings = [];
    sayingsText = [];
    const sayingsStart = handlerInput.t('SAYINGS_START');
    const sayingsEnd = handlerInput.t('SAYINGS_END');
    let sayingsOptions = Array.from({ length: sayingsStart.length }, (_, index) => index);
    for(var i = 0; i < 5; i++) {
        let opt = Math.floor(Math.random() * sayingsOptions.length);
        sayingsStartOrder[i] = sayingsOptions[opt];
        sayings[i] = [sayingsStart[sayingsOptions[opt]], sayingsEnd[sayingsOptions[opt]]];
        sayingsOptions.splice(opt, 1);
    }
    
    sayingsOptions = Array.from({ length: sayingsStartOrder.length }, (_, index) => index);
    for(var j = 0; j < 5; j++) {
        let opt = Math.floor(Math.random() * sayingsOptions.length);
        if((j !== 4) && (sayingsStartOrder[j] === sayingsStartOrder[sayingsOptions[opt]])){
            j--
        } else {
            sayingsEndOrder[j] = sayingsStartOrder[sayingsOptions[opt]];
            sayingsOptions.splice(opt, 1);
        }
    }
    
    for(var k = 0; k < sayingsStartOrder.length; k++) {
        const text = sayings[k][0][0];
        sayingsText[k] = [text.charAt(0).toUpperCase() + text.slice(1) + "...", sayingsEnd[sayingsEndOrder[k]][0]];
    }
}

// Function that initializes data for finding pairs game
function initializePairs(sessionAttributes) {
    for(var i = 1; i <=20; i++) {
        sessionAttributes["card" + i] = "";
    }

    for(var j = 1; j <=20; j++) {
        sessionAttributes["color" + j] = "";
    }
    
    sessionAttributes['lastCard1'] = "0";
    sessionAttributes['lastCard2'] = "0";
    sessionAttributes['pairsText'] = "";
    sessionAttributes['pairsLeft'] = 0;
    sessionAttributes['pairsTries'] = 0;
    sessionAttributes['match'] = 0;
}

// Function that initializes data for image descriptions minigame
function initializeImageDescription(sessionAttributes) {
    sessionAttributes['imagesTurn'] = 1;
    sessionAttributes['imagesCorrect'] = 0;
    sessionAttributes['imagesOpacity'] = 1;
    sessionAttributes['imagesFrameColor1'] = "";
    sessionAttributes['imagesFrameColor2'] = "";
    sessionAttributes['imagesFrameColor3'] = "";
    sessionAttributes['imagesFrameColor4'] = "";
}

// Function that initializes data for sayings minigame
function initializeSayings(handlerInput) {
    let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    
    randomSayings(handlerInput);
    for(var i = 1; i <= 5; i++) {
        sessionAttributes["squareLeft" + i] = "0vw";
    }
    for(var j = 1; j <= 5; j++) {
        sessionAttributes["squareRight" + j] = "0vw";
    }
    
    for(var k = 1; k <= 5; k++) {
        sessionAttributes["squareBorderColor" + k] = "";
    }
    sessionAttributes['halfSayingIndex'] = 10;
    sessionAttributes['sayingsTurn'] = 1;
    sessionAttributes['sayingsOpacity'] = 1;
    sessionAttributes['sayingsAvatarOpacity'] = 0;
}

// Function that initializes data for map puzzle minigame
function initializePuzzle(sessionAttributes) {
    for(var j = 1; j <=8; j++) {
        sessionAttributes["puzzleImOp" + j] = 1;
    }
    for(var k = 1; k <=8; k++) {
        sessionAttributes["puzzlePlOp" + k] = 0;
    }
    for(var l = 1; l <=8; l++) {
        sessionAttributes["puzzleImBorder" + l] = 0;
    }
    
    sessionAttributes['pieceSelected'] = "0";
    sessionAttributes['puzzleCorrect'] = 0;
    sessionAttributes['puzzleTurn'] = 1;
} 

// Function that initializes data for monument search minigame
function initializeLabyrinth(sessionAttributes) {
    // Laberinto
    sessionAttributes['labEnded'] = 0;
    sessionAttributes['labTurn'] = 1;
    sessionAttributes['moves'] = 5;
    sessionAttributes['labP1end'] = 0;
    sessionAttributes['labP2end'] = 0;
    sessionAttributes['labP3end'] = 0;
    sessionAttributes['labP4end'] = 0;
    sessionAttributes['questions'] = 4;
    sessionAttributes['onQuestion'] = 1;
    sessionAttributes['labTopP1'] = "25vh";
    sessionAttributes['labLeftP1'] = "18vw";
    sessionAttributes['labTopP2'] = "81vh";
    sessionAttributes['labLeftP2'] = "18vw";
    sessionAttributes['labTopP3'] = "25vh";
    sessionAttributes['labLeftP3'] = "91.5vw";
    sessionAttributes['labTopP4'] = "81vh";
    sessionAttributes['labLeftP4'] = "91.5vw";
    sessionAttributes['p1BorderColor'] = "",
    sessionAttributes['p2BorderColor'] = "",
    sessionAttributes['p3BorderColor'] = "",
    sessionAttributes['p4BorderColor'] = "",
    
    sessionAttributes['questionOpacity'] = 1;
    sessionAttributes['mapOpacity'] = 0.5;
    sessionAttributes['monument1Opacity'] = 0;
    sessionAttributes['monument2Opacity'] = 0;
    sessionAttributes['monument3Opacity'] = 0;
    sessionAttributes['monument4Opacity'] = 0;
    sessionAttributes['labBorderOp1'] = "";
    sessionAttributes['labBorderOp2'] = "";
    sessionAttributes['labBorderOp3'] = "";
    sessionAttributes['labBorderOp4'] = "";
    sessionAttributes['searchEndOpacity'] = 1;
}   

// Function that initializes Finding the Map game
function initializeMapSearch(handlerInput) {
    let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
    sessionAttributes['phase'] = 0;
    sessionAttributes['lastSpeech'] = '';
    sessionAttributes['searchDoc'] = '';
    sessionAttributes['plural'] = 0;
    initializeImageDescription(sessionAttributes);
    initializeSayings(handlerInput);
    initializePuzzle(sessionAttributes);
    initializeLabyrinth(sessionAttributes);
}

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        sessionAttributes['lastIntent'] = "LaunchIntent";
        let speakOutput = handlerInput.t('ASK_NAME');
        sessionAttributes['lastSpeech'] = handlerInput.t('ASK_NAME');
        
        handlerInput.responseBuilder.addDirective({
            type: 'Alexa.Presentation.APL.RenderDocument',
            version: '1.1',
            document: constants.APL.askNameDoc,
            datasources: {
                askNameData: {
                    type: 'object',
                    properties: {
                        questionText: handlerInput.t('ASK_NAME_TEXT'),
                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png")
                    }
                }
            }
        });
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const IdentificationRequestHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'IdentificationIntent')
    },
    handle(handlerInput) {
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = "";
        // if(sessionAttributes['lastIntent'] === "LaunchIntent") { // No lo detecta a pesar de ser el mismo valor
        if(!sessionAttributes['loaded']) {
            sessionAttributes['lastIntent'] = "IdentificationIntent";
            sessionAttributes['username'] = Alexa.getSlotValue(handlerInput.requestEnvelope, 'name')
            
            speakOutput = handlerInput.t('WELCOME', { name: sessionAttributes['username'] }) + halfSecondPause + handlerInput.t('GAME_MODE_INSTRUCTIONS');
            
            sessionAttributes['lastSpeech'] = handlerInput.t('GAME_MODE_INSTRUCTIONS');
            if (!sessionAttributes['phase']) {
                sessionAttributes['phase'] = -1;
            }
            handlerInput.responseBuilder.addDirective({
                type: 'Alexa.Presentation.APL.RenderDocument',
                version: '1.1',
                document: constants.APL.welcomeDoc,
                datasources: {
                    welcomeData: {
                        type: 'object',
                        properties: {
                            touchButtonText: handlerInput.t('TOUCH_TEXT'),
                            voiceButtonText: handlerInput.t('VOICE_TEXT'),
                            fullButtonText: handlerInput.t('FULL_TEXT'),
                            questionText: handlerInput.t('MODE_QUESTION_TEXT'),
                            helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png")
                        }
                    }
                }
            });
        }
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

const InteractionModeIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'InteractionModeIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'modeButton');
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = "";
        
        if((sessionAttributes['lastIntent'] === 'IdentificationIntent') || (sessionAttributes['lastIntent'] === 'InteractionModeIntent')) {
            if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
               ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
                let mode = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') mode = mode + Alexa.getSlotValue(handlerInput.requestEnvelope, 'mode');
                else mode = handlerInput.requestEnvelope.request.arguments[0];
                
                if((mode === "touch") || (mode === handlerInput.t('TOUCH'))) {
                    sessionAttributes['mode'] = "TOUCH";
                    sessionAttributes['buttonsOpacity'] = 1;
                    sessionAttributes['disableButtons'] = false;
                }else if ((mode === "voice") || (mode === handlerInput.t('VOICE'))) {
                    sessionAttributes['mode'] = "VOICE";
                    sessionAttributes['buttonsOpacity'] = 0;
                    sessionAttributes['disableButtons'] = true;
                }
                else if ((mode === "full") || (mode === handlerInput.t('FULL'))) {
                    sessionAttributes['mode'] = "FULL";
                    sessionAttributes['buttonsOpacity'] = 1;
                    sessionAttributes['disableButtons'] = false;
                }
                else {
                    return handlerInput.responseBuilder
                        .speak(handlerInput.t('GAME_MODE_INSTRUCTIONS') + oneMinuteOfSilence)
                        .reprompt(handlerInput.t('GAME_MODE_INSTRUCTIONS') + oneMinuteOfSilence)
                        .getResponse();
                }
                
                sessionAttributes['lastIntent'] = "CatalogIntent";
                speakOutput = handlerInput.t('GAME_CHOICE') + halfSecondPause + handlerInput.t('CATALOG_INSTRUCTIONS_' + sessionAttributes['mode']);
                sessionAttributes['lastSpeech'] = speakOutput;
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.catalogDoc,
                    datasources: {
                        catalogData: {
                            type: 'object',
                            properties: {
                                title: handlerInput.t('GAME_CHOICE'),
                                game1: handlerInput.t('GAME_1'),
                                imageGame1: Util.getS3PreSignedUrl("Media/find_pairs_image.png"),
                                game2: handlerInput.t('GAME_2'),
                                imageGame2: Util.getS3PreSignedUrl("Media/guess_sport_image.png"),
                                game3: handlerInput.t('GAME_3'),
                                imageGame3: Util.getS3PreSignedUrl("Media/map_search_image.png"),
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            }
        }
        return handlerInput.responseBuilder
                .speak(speakOutput + oneMinuteOfSilence)
                .reprompt(speakOutput)
                .getResponse();
    }
};

const GoBackIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GoBackIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'exitButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'gameExitButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'catalogExitButton');
    },
    handle(handlerInput) {
        let sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = '';
        if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
           ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
            
            if(sessionAttributes['lastIntent'] === "CatalogIntent") {
                sessionAttributes['lastIntent'] = "InteractionModeIntent";
                speakOutput = handlerInput.t('GAME_MODE_INSTRUCTIONS');
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.welcomeDoc,
                    datasources: {
                        welcomeData: {
                            type: 'object',
                            properties: {
                                touchButtonText: handlerInput.t('TOUCH_TEXT'),
                                voiceButtonText: handlerInput.t('VOICE_TEXT'),
                                fullButtonText: handlerInput.t('FULL_TEXT'),
                                questionText: handlerInput.t('MODE_QUESTION_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png")
                            }
                        }
                    }
                });
            } else {
                speakOutput = handlerInput.t('BACK_AT_CATALOG') + halfSecondPause;
                let text = handlerInput.t('GAME_CHOICE');
                text = text + halfSecondPause + handlerInput.t('CATALOG_INSTRUCTIONS_' + sessionAttributes['mode']);
                
                sessionAttributes['lastSpeech'] = text;
                speakOutput = speakOutput + text;
                
                if(sessionAttributes['lastIntent'] === "PairsIntent"){
                
                    if(sessionAttributes['pairsEnd'] !== 1) {
                        const lastCard1 = sessionAttributes['lastCard1'];
                        const lastCard2 = sessionAttributes['lastCard2'];
                        
                        if(sessionAttributes['match'] === 0) {
                            if(lastCard1 !== 0) sessionAttributes["card" + lastCard1] = "";
                            if(lastCard2 !== 0) sessionAttributes["card" + lastCard2] = "";
                        }
                        sessionAttributes['lastCard1'] = "0";
                        sessionAttributes['lastCard2'] = "0";
                    } else { // Initialize pairs info if game ended
                        initializePairs(sessionAttributes);
                        sessionAttributes['pairsEnd'] = -1;
                    }
                }
                
                if(sessionAttributes['mapSearchEnd'] === 1) { // Initialize map search info if game ended
                    initializeMapSearch(handlerInput);
                    sessionAttributes['mapSearchEnd'] = 0;
                }
                if(sessionAttributes['pieceSelected'] && (sessionAttributes['pieceSelected'] !== "0")) {
                    sessionAttributes['puzzleImBorder' + sessionAttributes['pieceSelected']] = 0;
                    sessionAttributes['pieceSelected'] = 0;
                }
                if(sessionAttributes['halfSayingIndex'] && (sessionAttributes['halfSayingIndex'] !== 10)) {
                    sessionAttributes['squareBorderColor' + (sessionAttributes['halfSayingIndex'] + 1)] = "";
                    sessionAttributes['halfSayingIndex'] = 10;
                }
                
                sessionAttributes['lastIntent'] = 'CatalogIntent';
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.catalogDoc,
                    datasources: {
                        catalogData: {
                            type: 'object',
                            properties: {
                                title: handlerInput.t('GAME_CHOICE'),
                                game1: handlerInput.t('GAME_1'),
                                imageGame1: Util.getS3PreSignedUrl("Media/find_pairs_image.png"),
                                game2: handlerInput.t('GAME_2'),
                                imageGame2: Util.getS3PreSignedUrl("Media/guess_sport_image.png"),
                                game3: handlerInput.t('GAME_3'),
                                imageGame3: Util.getS3PreSignedUrl("Media/map_search_image.png"),
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            }
        }

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CatalogIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'catalogGameButton')  
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CatalogIntent');
    },
    handle(handlerInput) {
        let speakOutput = '';
        
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        if(sessionAttributes['lastIntent'] === "CatalogIntent") {
            if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
               ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
                let palabra = 'ejemplo';
                let gameId = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') gameId = gameId + Alexa.getSlotValue(handlerInput.requestEnvelope, 'game');
                else gameId = handlerInput.requestEnvelope.request.arguments[0];
                
                if(handlerInput.t('GAME_1').toLowerCase() === gameId) gameId = "1";
                if(handlerInput.t('GAME_2').toLowerCase() === gameId) gameId = "2";
                if(handlerInput.t('GAME_3').toLowerCase() === gameId) gameId = "3";
                sessionAttributes['gameId'] = gameId;
                
                if (gameId === "1") {
                    if(sessionAttributes['pairsEnd'] === 0) {
                        sessionAttributes['lastIntent'] = "RestorePairs";
                        sessionAttributes['askRestoreData'] = 'true';
                        speakOutput = handlerInput.t('GAME_PLAYING', {game: handlerInput.t('GAME_' + gameId)}) + halfSecondPause + handlerInput.t('LOAD_GAME_QUESTION');
                        const neg = handlerInput.t('NO');
                        const aff = handlerInput.t('YES');
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.loadGameDoc,
                            datasources: {
                                loadGameData: {
                                    type: 'object',
                                    properties: {
                                        noButtonText: neg[0].toUpperCase(),
                                        yesButtonText: aff[0].toUpperCase(),
                                        questionText: handlerInput.t('LOAD_GAME_QUESTION'),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else {
                        sessionAttributes['lastIntent'] = 'ChooseLevel';
                        speakOutput = handlerInput.t('LEVEL_PAIRS_' + sessionAttributes['mode']);
                        
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.pairsLevelDoc,
                            datasources: {
                                pairsLevelData: {
                                    type: 'object',
                                    properties: {
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        title: handlerInput.t('PAIRS_TITLE'),
                                        subTitle: handlerInput.t('PAIRS_SUB_TITLE'),
                                        easy: handlerInput.t('PAIRS_LEVEL_EASY'),
                                        medium: handlerInput.t('PAIRS_LEVEL_MEDIUM'),
                                        hard: handlerInput.t('PAIRS_LEVEL_HARD'),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    }
                    
                    return handlerInput.responseBuilder
                        .speak(speakOutput + oneMinuteOfSilence)
                        .reprompt('Error')
                        .getResponse();
                    
                } else if (gameId === "2") {
                    sessionAttributes['lastIntent'] = "SportsIntent";
                    sessionAttributes['guessed'] = 0;
                    
                    speakOutput = handlerInput.t('GAME_PLAYING', handlerInput.t('GAME_' + gameId));
                    
                    const sports = handlerInput.t('SPORTS');
                    randomSports(sports);
                    sessionAttributes['sportsEndOpacity'] = 1;
                    sessionAttributes['sportsRound'] = 0;
                    sessionAttributes['sportsEnded'] = 0;
                    const roundInfo = sportsInfo[0];
                    if(!sessionAttributes['bestStreak'])
                        sessionAttributes['bestStreak'] = 0;
                    
                    speakOutput = speakOutput + halfSecondPause + handlerInput.t('SPORTS_QUESTION', {sport1: sports[roundInfo[1]][0], sport2: sports[roundInfo[2]][0], sport3: sports[roundInfo[3]][0]});
                    speakOutput = speakOutput + halfSecondPause + handlerInput.t('SPORTS_INSTRUCTIONS_' + sessionAttributes['mode'], {sport1: sports[roundInfo[1]][0], sport2: sports[roundInfo[2]][0], sport3: sports[roundInfo[3]][0]});
                    
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.sportsDoc,
                        datasources: {
                            sportsData: {
                                type: 'object',
                                properties: {
                                    image: Util.getS3PreSignedUrl("Media/" + roundInfo[4]),
                                    sport1: sports[roundInfo[1]][0],
                                    sport2: sports[roundInfo[2]][0],
                                    sport3: sports[roundInfo[3]][0],
                                    guessed: handlerInput.t('SPORTS_GUESSES', { guessed: sessionAttributes['guessed'] }),
                                    bestStreak: sessionAttributes['bestStreak'],
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                    endOpacity: sessionAttributes['sportsEndOpacity']
                                }
                            }
                        }
                    });
                } else if (gameId === "3") {
                    if((sessionAttributes['phase'] > 0) && (sessionAttributes['mapSearchEnd'] !== 1)) {
                        sessionAttributes['lastIntent'] = "RestoreSearch";
                        sessionAttributes['askRestoreData'] = 'true';
                        sessionAttributes['plural'] = 0;
                        speakOutput = handlerInput.t('GAME_PLAYING', {game: handlerInput.t('GAME_' + gameId)}) + halfSecondPause + handlerInput.t('LOAD_GAME_QUESTION');
                        const neg = handlerInput.t('NO');
                        const aff = handlerInput.t('YES');
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.loadGameDoc,
                            datasources: {
                                loadGameData: {
                                    type: 'object',
                                    properties: {
                                        noButtonText: neg[0].toUpperCase(),
                                        yesButtonText: aff[0].toUpperCase(),
                                        questionText: handlerInput.t('LOAD_GAME_QUESTION'),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else {
                        sessionAttributes['lastIntent'] = "ChoosePlayers";
                        speakOutput = handlerInput.t('CHOOSE_PLAYERS_QUESTION') + handlerInput.t('CHOOSE_PLAYERS_INSTRUCTIONS_' + sessionAttributes['mode']);
                        sessionAttributes['lastSpeech'] = speakOutput;
                        
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.choosePlayersDoc,
                            datasources: {
                                choosePlayersData: {
                                    type: 'object',
                                    properties: {
                                        title: handlerInput.t('GAME_3'),
                                        subTitle: handlerInput.t('CHOOSE_PLAYERS_QUESTION'),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    }
                }
            }
    
        } else {
            speakOutput = handlerInput.t('CATALOG_ERROR');
        }
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const PairsLevelIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'PairsLevelIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'pairsLevel')
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = "";
        if(sessionAttributes['lastIntent'] === 'ChooseLevel') {
            if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
               ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
                let level = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') level = level + Alexa.getSlotValue(handlerInput.requestEnvelope, 'level');
                else level = handlerInput.requestEnvelope.request.arguments[0];
                
                let my_level = "";
                let pairs = 0;
                if(level === "easy" || level === handlerInput.t('PAIRS_LEVEL_EASY').toLowerCase()) {
                    sessionAttributes["pairsLevel"] = "easy";
                    sessionAttributes["pairsDoc"] = constants.APL.pairsEasyDoc;
                    pairs = 12;
                    my_level = handlerInput.t('PAIRS_LEVEL_EASY');
                } else if(level === "medium" || level === handlerInput.t('PAIRS_LEVEL_MEDIUM').toLowerCase()){
                    sessionAttributes["pairsLevel"] = "medium";
                    sessionAttributes["pairsDoc"] = constants.APL.pairsMediumDoc;
                    pairs = 16;
                    my_level = handlerInput.t('PAIRS_LEVEL_MEDIUM');
                } else if(level === "hard" || level === handlerInput.t('PAIRS_LEVEL_HARD').toLowerCase()){
                    sessionAttributes["pairsLevel"] = "hard";
                    sessionAttributes["pairsDoc"] = constants.APL.pairsHardDoc;
                    pairs = 20;
                    my_level = handlerInput.t('PAIRS_LEVEL_HARD');
                } else {
                    return handlerInput.responseBuilder
                        .speak(speakOutput + oneMinuteOfSilence)
                        .reprompt(speakOutput)
                        .getResponse();
                }
                
                // Initialize parameters
                initializePairs(sessionAttributes);
                sessionAttributes["pairsLeft"] = pairs/2;
                randomColors(sessionAttributes, pairs);
                
                
                sessionAttributes['lastIntent'] = 'PairsIntent';
                sessionAttributes['pairsEnd'] = 0;
                speakOutput = handlerInput.t('CHOSEN_LEVEL', {level: my_level}) + halfSecondPause + handlerInput.t('PAIRS_INSTRUCTIONS_' + sessionAttributes['mode']);
                sessionAttributes['lastSpeech'] = handlerInput.t('PAIRS_INSTRUCTIONS_' + sessionAttributes['mode']);
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: sessionAttributes["pairsDoc"],
                    datasources: {
                        pairsData: {
                            type: 'object',
                            properties: {
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                title: handlerInput.t('PAIRS_TITLE'),
                                pairsText: "",
                                triesText: handlerInput.t('TRIES'),
                                tries: sessionAttributes['pairsTries'],
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                color1: sessionAttributes["card1"],
                                color2: sessionAttributes["card2"],
                                color3: sessionAttributes["card3"],
                                color4: sessionAttributes["card4"],
                                color5: sessionAttributes["card5"],
                                color6: sessionAttributes["card6"],
                                color7: sessionAttributes["card7"],
                                color8: sessionAttributes["card8"],
                                color9: sessionAttributes["card9"],
                                color10: sessionAttributes["card10"],
                                color11: sessionAttributes["card11"],
                                color12: sessionAttributes["card12"],
                                color13: sessionAttributes["card13"],
                                color14: sessionAttributes["card14"],
                                color15: sessionAttributes["card15"],
                                color16: sessionAttributes["card16"],
                                color17: sessionAttributes["card17"],
                                color18: sessionAttributes["card18"],
                                color19: sessionAttributes["card19"],
                                color20: sessionAttributes["card20"],
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            }
        }
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

// **********  ACIERTA EL DEPORTE ************
const SportsIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SportsIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'sportButton');
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        const {intent} = handlerInput.requestEnvelope.request;     // Where slot information is located
        let speakOutput = "";
        const sports = handlerInput.t('SPORTS');
        
        if(sessionAttributes['lastIntent'] === "SportsIntent") {
            if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
               ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
                let roundInfo = sportsInfo[sessionAttributes['sportsRound']];
                if(sessionAttributes['sportsEnded'] === 1) {
                    speakOutput = handlerInput.t('EXIT_GAME_' + sessionAttributes['mode'])[0];
                } else {
                    let sport = "";
                    if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                        sport = sport + Alexa.getSlotValue(handlerInput.requestEnvelope, 'sport');
                    } else {
                        const sportAux = handlerInput.requestEnvelope.request.arguments[0];
                        sport = sports[roundInfo[parseInt(sportAux)]][1];
                    }
                    
                    speakOutput = sport + ". ";
                    if(roundInfo[5] === sport) {
                        speakOutput = speakOutput + handlerInput.t('CORRECT');
                        if(sessionAttributes['sportsRound'] === (sportsInfo.length - 1)) {
                            sessionAttributes['sportsEndOpacity'] = 0;
                            sessionAttributes['sportsRound'] = 0;
                            speakOutput = speakOutput + halfSecondPause + handlerInput.t('SPORTS_END_' + sessionAttributes['mode']);
                            sessionAttributes['sportsEnded'] = 1;
                            sessionAttributes['guessed'] = sessionAttributes['guessed'] + 1;
                            if(sessionAttributes['guessed'] > sessionAttributes['bestStreak'])
                                sessionAttributes['bestStreak'] = sessionAttributes['guessed'];
                        } else {
                            sessionAttributes['sportsRound'] = sessionAttributes['sportsRound'] + 1;
                            sessionAttributes['guessed'] = sessionAttributes['guessed'] + 1;
                            roundInfo = sportsInfo[sessionAttributes['sportsRound']];
                            speakOutput = speakOutput + halfSecondPause + handlerInput.t('SPORTS_QUESTION', {sport1: sports[roundInfo[1]][0], sport2: sports[roundInfo[2]][0], sport3: sports[roundInfo[3]][0]});
                        }
                    } else {
                        speakOutput = speakOutput + ". Vuelve a intentalo";
                        const sports = handlerInput.t('SPORTS');
                        let lastSport = sportsInfo[sessionAttributes['sportsRound']]
                        randomSports(sports);
                        sessionAttributes['sportsRound'] = 0;
                        sportsInfo.unshift(lastSport);
                        roundInfo = sportsInfo[sessionAttributes['sportsRound']];
                        if(sessionAttributes['guessed'] > sessionAttributes['bestStreak']) {
                            sessionAttributes['bestStreak'] = sessionAttributes['guessed'];
                        }
                        sessionAttributes['guessed'] = 0;
                    }
                    
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.sportsDoc,
                        datasources: {
                            sportsData: {
                                type: 'object',
                                properties: {
                                    image: Util.getS3PreSignedUrl("Media/" + roundInfo[4]),
                                    sport1: sports[roundInfo[1]][0],
                                    sport2: sports[roundInfo[2]][0],
                                    sport3: sports[roundInfo[3]][0],
                                    guessed: sessionAttributes['guessed'],
                                    bestStreak: sessionAttributes['bestStreak'],
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                    endOpacity: sessionAttributes['sportsEndOpacity']
                                }
                            }
                        }
                    });
                }
            }
        }
            
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput)
            .getResponse();
    }
};

// ********** ENCONTREMOS EL MAPA ************
const ImagesRequestHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ImagesIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'pairsButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'imageButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'puzzleMapButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'numPlayersButton');
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        const {intent} = handlerInput.requestEnvelope.request;     // Where slot information is located
        let speakOutput = "";
        let plural = sessionAttributes['plural'];
        
        // Just allow to interact if 
        if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) || 
           ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
            if(sessionAttributes['lastIntent'] === "PairsIntent") {
                let card = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                    card = card + Alexa.getSlotValue(handlerInput.requestEnvelope, 'image');
                    if(card === 'undefined') {
                        card = Alexa.getSlotValue(handlerInput.requestEnvelope, 'place');
                    }
                }else {
                    card = handlerInput.requestEnvelope.request.arguments[0];
                }
                let text = "";
                let directive = 1;
                if(sessionAttributes['pairsEnd'] === 1) {
                    sessionAttributes['match'] = 0;
                    speakOutput = handlerInput.t('EXIT_GAME_' + sessionAttributes['mode'])[0];
                } else {
                    let lastCard1 = sessionAttributes['lastCard1'];
                    let lastCard2 = sessionAttributes['lastCard2'];
                    
                    if(lastCard1 === "0") { // It's the first card of the pair
                        if((!sessionAttributes['card' + card]) || (sessionAttributes['card' + card] === "")) {
                            sessionAttributes['match'] = 0;
                            sessionAttributes['lastCard1'] = card; // Card is upside down
                        } else {
                            directive = 0;
                        }
                    } else if (lastCard2 === "0") { // It's the second card of the pair
                        if(((!sessionAttributes['card' + card]) || (sessionAttributes['card' + card] === "")) && (lastCard1 !== card)) {
                            sessionAttributes['pairsTries'] = sessionAttributes['pairsTries'] + 1;
                            if (sessionAttributes["color" + lastCard1] === sessionAttributes["color" + card]) { // They are the same color
                                sessionAttributes['match'] = 1;
                                sessionAttributes['lastCard1'] = "0";
                                sessionAttributes['pairsLeft'] = sessionAttributes['pairsLeft'] - 1;
                                text = handlerInput.t('CORRECT');
                                speakOutput = text;
                                if (sessionAttributes['pairsLeft'] === 0) {
                                    sessionAttributes['pairsEnd'] = 1;
                                    speakOutput = oneSecondPause + handlerInput.t('END_PAIRS_' + sessionAttributes['mode']);
                                }
                            } else { // They are not the same color
                                sessionAttributes['match'] = 0;
                                sessionAttributes['lastCard2'] = lastCard1;
                                sessionAttributes['lastCard1'] = card;
                            }
                        } else {
                            directive = 0;
                        }
                    } else { // Last pair does not match
                        sessionAttributes["card" + lastCard1] = "";
                        sessionAttributes["card" + lastCard2] = "";
                        if((card === lastCard1) || (card === lastCard2) || ((!sessionAttributes['card' + card]) || (sessionAttributes['card' + card] === ""))) {
                            sessionAttributes['lastCard1'] = card;
                        } else { 
                            sessionAttributes['lastCard1'] = "0";
                        }
                        sessionAttributes['lastCard2'] = "0";
                    }
                    
                    sessionAttributes["card" + card] = Util.getS3PreSignedUrl("Media/" + sessionAttributes["color" + card] + ".png");
                    if(directive === 1) {
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: sessionAttributes["pairsDoc"],
                            datasources: {
                                pairsData: {
                                    type: 'object',
                                    properties: {
                                        title: handlerInput.t('PAIRS_TITLE'),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        pairsText: text,
                                        triesText: handlerInput.t('TRIES'),
                                        tries: sessionAttributes['pairsTries'],
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        color1: sessionAttributes["card1"],
                                        color2: sessionAttributes["card2"],
                                        color3: sessionAttributes["card3"],
                                        color4: sessionAttributes["card4"],
                                        color5: sessionAttributes["card5"],
                                        color6: sessionAttributes["card6"],
                                        color7: sessionAttributes["card7"],
                                        color8: sessionAttributes["card8"],
                                        color9: sessionAttributes["card9"],
                                        color10: sessionAttributes["card10"],
                                        color11: sessionAttributes["card11"],
                                        color12: sessionAttributes["card12"],
                                        color13: sessionAttributes["card13"],
                                        color14: sessionAttributes["card14"],
                                        color15: sessionAttributes["card15"],
                                        color16: sessionAttributes["card16"],
                                        color17: sessionAttributes["card17"],
                                        color18: sessionAttributes["card18"],
                                        color19: sessionAttributes["card19"],
                                        color20: sessionAttributes["card20"],
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    }
                }
            } else if (sessionAttributes['lastIntent'] === 'ChoosePlayers') {
                let numPlayers = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                    numPlayers = parseInt(Alexa.getSlotValue(handlerInput.requestEnvelope, 'image'));
                } else numPlayers = parseInt(handlerInput.requestEnvelope.request.arguments[0]);
                
                if(numPlayers === 1) nextPlayer = ["1","1","1","1"];
                else if(numPlayers === 2) nextPlayer = ["1","2","1","2"];
                else if(numPlayers === 4) nextPlayer = ["1","2","3","4"];
                else {
                    return handlerInput.responseBuilder
                        .speak(handlerInput.t('WRONG_PLAYERS') + oneMinuteOfSilence)
                        .reprompt(handlerInput.t('WRONG_PLAYERS') + oneMinuteOfSilence)
                        .getResponse();
                }
                
                initializeMapSearch(handlerInput);
                if(numPlayers > 1) sessionAttributes['plural'] = 1;
                sessionAttributes['sightseeingPlayers'] = numPlayers;
                
                sessionAttributes['lastIntent'] = "MapSearchIntent";
                speakOutput = (handlerInput.t('GREETING')[sessionAttributes['plural']]);
                sessionAttributes['lastSpeech'] = speakOutput;
                
                sessionAttributes['mapSearchEnd'] = 0;
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.launchDoc,
                    datasources: {
                        sightseeingData: {
                            type: 'object',
                            properties: {
                                parkImage: Util.getS3PreSignedUrl("Media/park.png"),
                                welcomeText: handlerInput.t('WELCOME_TEXT')[sessionAttributes['plural']],
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            } else {
                if(sessionAttributes['phase'] === 1) {
                    let image = 0;
                    if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') image = Alexa.getSlotValue(handlerInput.requestEnvelope, 'image');
                    else image = parseInt(handlerInput.requestEnvelope.request.arguments[0]);
                    let turn = sessionAttributes['imagesTurn'];
                    
                    if(parseInt(image) > 4 ) {
                        speakOutput = (handlerInput.t('WRONG_NUMBER', { number1: "1", number2: "4" })[plural]);
                    } else {
                        if(turn > 4) {
                            speakOutput = handlerInput.t('FIRST_GAME_END');
                            speakOutput = speakOutput + halfSecondPause + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                            sessionAttributes['lastSpeech'] = speakOutput;
                        } else {
                            let directive = 0;
                            let readDescription = 1;
                            if(image) {
                                image = parseInt(image);
                                speakOutput = (handlerInput.t('CORRECT_PIECE', { group: nextPlayer[turn - 1] })[plural]);
                                if(turn === 1 && image === 3) {
                                    turn = turn + 1;
                                } else if(turn === 2 && image === 1) {
                                    turn = turn + 1;
                                } else if(turn === 3 && image === 4) {
                                    turn = turn + 1;
                                } else if(turn === 4 && image === 2) {
                                    turn = turn + 1;
                                } else {
                                    speakOutput = handlerInput.t('WRONG_PIECE')[plural];
                                    sessionAttributes['imagesFrameColor' + image] = 'red';
                                    readDescription = 0;
                                }
                                directive = 1;
                                if(turn > 4) {
                                    sessionAttributes['imagesFrameColor1'] = "";
                                    sessionAttributes['imagesFrameColor2'] = "";
                                    sessionAttributes['imagesFrameColor3'] = "";
                                    sessionAttributes['imagesFrameColor4'] = "";
                                    sessionAttributes['imagesOpacity'] = 0;
                                    let lastSpeech = handlerInput.t('FIRST_GAME_END');
                                    lastSpeech = lastSpeech + halfSecondPause + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                                    sessionAttributes['lastSpeech'] = lastSpeech;
                                    speakOutput = speakOutput + halfSecondPause + lastSpeech;
                                } else if(readDescription === 1) {
                                    let text = (handlerInput.t('PREPARE_FOR_DESCRIPTION', { group: nextPlayer[turn - 1] })[plural]);
                                    text = text + handlerInput.t('IMAGE_DESCRIPTION_' + turn);
                                    text = text + handlerInput.t('IMAGE_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                                    sessionAttributes['lastSpeech'] = text;
                                    speakOutput = speakOutput + halfSecondPause + text;
                                    for (var i = 1; i < 5; i++) {
                                        sessionAttributes['imagesFrameColor' + i] = "";
                                    }
                                    directive = 1
                                }
                                sessionAttributes['imagesTurn'] = turn;
                            }
                            
                            if(directive === 1) {
                                handlerInput.responseBuilder.addDirective({
                                    type: 'Alexa.Presentation.APL.RenderDocument',
                                    version: '1.1',
                                    document: constants.APL.imagesDoc,
                                    datasources: {
                                        imagesData: {
                                            type: 'object',
                                            properties: {
                                                title: handlerInput.t('IMAGES_TITLE'),
                                                turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['imagesTurn'] - 1] })[plural],
                                                image1: Util.getS3PreSignedUrl("Media/Option" + (turn) + "-0.png"),
                                                image2: Util.getS3PreSignedUrl("Media/Option" + (turn) + "-1.png"),
                                                image3: Util.getS3PreSignedUrl("Media/Option" + (turn) + "-2.png"),
                                                image4: Util.getS3PreSignedUrl("Media/Option" + (turn) + "-3.png"),
                                                endingOpacity: sessionAttributes['imagesOpacity'],
                                                frameColor1: sessionAttributes['imagesFrameColor1'],
                                                frameColor2: sessionAttributes['imagesFrameColor2'],
                                                frameColor3: sessionAttributes['imagesFrameColor3'],
                                                frameColor4: sessionAttributes['imagesFrameColor4'],
                                                repeat_image: Util.getS3PreSignedUrl("Media/repeat_image.png"),
                                                avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                                disableButtons: sessionAttributes['disableButtons'],
                                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    }
                } else if(sessionAttributes['phase'] === 3) {
                    let place = "";
                    let image = "";
                    if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                        image = Alexa.getSlotValue(handlerInput.requestEnvelope, 'image');
                        place = Alexa.getSlotValue(handlerInput.requestEnvelope, 'place');
                    } else image = handlerInput.requestEnvelope.request.arguments[0];
                    
                    if(sessionAttributes['puzzleCorrect'] === 8) {
                        let lastSpeech = handlerInput.t('LETS_GO_SIGHTSEEING')[plural];
                        lastSpeech = lastSpeech + halfSecondPause + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                        sessionAttributes['lastSpeech'] = lastSpeech;
                        speakOutput = speakOutput + halfSecondPause + lastSpeech;
                    }
                    else {
                        let directive = 0;
                        if(place !== "") {
                            //const image = parseInt(image);
                            //const place = parseInt(place);
                            
                            if(pieces.indexOf(image) === places.indexOf(place)) {
                                sessionAttributes['puzzleTurn'] = sessionAttributes['puzzleTurn'] + 1;
                                sessionAttributes['puzzleImOp' + image] = 0;
                                sessionAttributes['puzzlePlOp' + place] = 1;
                                sessionAttributes['puzzleCorrect'] = sessionAttributes['puzzleCorrect'] + 1;
                                speakOutput = handlerInput.t('CORRECT_PIECE_POSITION');
                                if(sessionAttributes['puzzleCorrect'] === 8) {
                                    let lastSpeech = handlerInput.t('LETS_GO_SIGHTSEEING')[plural];
                                    lastSpeech = lastSpeech + twoSecondsPause +  handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                                    sessionAttributes['lastSpeech'] = lastSpeech;
                                    speakOutput = speakOutput + halfSecondPause + lastSpeech;
                                }
                                else {
                                    if(sessionAttributes['puzzleTurn'] > 4) sessionAttributes['puzzleTurn'] = 1;
                                    speakOutput = speakOutput + halfSecondPause + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1] })[plural] + ". Debería ser " + sessionAttributes['puzzleTurn'];
                                }
                                directive = 1;
                            } else {
                                speakOutput = handlerInput.t('WRONG_PIECE_POSITION');
                            }
                                
                        } else {
                            if(parseInt(image) < 9) {
                                if(sessionAttributes['puzzleImOp' + image] === 1) {
                                    sessionAttributes['puzzleImBorder' + image] = 3;
                                    if(sessionAttributes['pieceSelected'] !== "0") {
                                        sessionAttributes['puzzleImBorder' + sessionAttributes['pieceSelected']] = 0;
                                    }
                                    sessionAttributes['pieceSelected'] = image;
                                    directive = 1;
                                }
                            } else if (parseInt(image) < 17){
                                if(sessionAttributes['pieceSelected'] !== 0) { //
                                    image = parseInt(image) - 8;
                                    if(sessionAttributes['puzzlePlOp' + image] === 0) {
                                        if(pieces.indexOf(sessionAttributes['pieceSelected']) === places.indexOf(""+ image)){
                                            sessionAttributes['puzzleImOp' + sessionAttributes['pieceSelected']] = 0;
                                            sessionAttributes['puzzlePlOp' + image] = 1;
                                            speakOutput = speakOutput + handlerInput.t('CORRECT_PIECE_POSITION');
                                            sessionAttributes['puzzleCorrect'] = sessionAttributes['puzzleCorrect'] + 1;
                                            sessionAttributes['puzzleTurn'] = sessionAttributes['puzzleTurn'] + 1;
                                            if(sessionAttributes['puzzleCorrect'] === 8) {
                                                let lastSpeech = handlerInput.t('LETS_GO_SIGHTSEEING')[plural];
                                                lastSpeech = lastSpeech + twoSecondsPause +  handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                                                sessionAttributes['lastSpeech'] = lastSpeech;
                                                speakOutput = speakOutput + halfSecondPause + lastSpeech;
                                            } else { 
                                                if(sessionAttributes['puzzleTurn'] > 4) sessionAttributes['puzzleTurn'] = 1;
                                                speakOutput = speakOutput + halfSecondPause + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1] })[plural];
                                            }
                                            sessionAttributes['pieceSelected'] = "0";
                                            directive = 1;
                                        } else {
                                            //sessionAttributes['puzzleImBorder' + sessionAttributes['pieceSelected']] = 0;
                                            speakOutput = handlerInput.t('WRONG_PIECE_POSITION');
                                            directive = 0;
                                        }
                                    }
                                } else {
                                    speakOutput = handlerInput.t('SELECT_PIECE');
                                }
                            } else {
                                speakOutput = handlerInput.t('OUT_OF_BOUNDS')
                            }
                        }
                        
                        if(directive === 1) {
                            handlerInput.responseBuilder.addDirective({
                                type: 'Alexa.Presentation.APL.RenderDocument',
                                version: '1.1',
                                document: constants.APL.puzzleDoc,
                                datasources: {
                                    puzzleData: {
                                        type: 'object',
                                        properties: {
                                            op1: sessionAttributes['puzzleImOp1'],
                                            op2: sessionAttributes['puzzleImOp2'],
                                            op3: sessionAttributes['puzzleImOp3'],
                                            op4: sessionAttributes['puzzleImOp4'], 
                                            op5: sessionAttributes['puzzleImOp5'],
                                            op6: sessionAttributes['puzzleImOp6'], 
                                            op7: sessionAttributes['puzzleImOp7'], 
                                            op8: sessionAttributes['puzzleImOp8'],
                                            op9: sessionAttributes['puzzlePlOp1'],
                                            op10: sessionAttributes['puzzlePlOp2'],
                                            op11: sessionAttributes['puzzlePlOp3'],
                                            op12: sessionAttributes['puzzlePlOp4'], 
                                            op13: sessionAttributes['puzzlePlOp5'],
                                            op14: sessionAttributes['puzzlePlOp6'], 
                                            op15: sessionAttributes['puzzlePlOp7'], 
                                            op16: sessionAttributes['puzzlePlOp8'],
                                            border1: sessionAttributes['puzzleImBorder1'],
                                            border2: sessionAttributes['puzzleImBorder2'],
                                            border3: sessionAttributes['puzzleImBorder3'],
                                            border4: sessionAttributes['puzzleImBorder4'], 
                                            border5: sessionAttributes['puzzleImBorder5'],
                                            border6: sessionAttributes['puzzleImBorder6'], 
                                            border7: sessionAttributes['puzzleImBorder7'], 
                                            border8: sessionAttributes['puzzleImBorder8'],
                                            exitButtonText: handlerInput.t('EXIT_TEXT'),
                                            continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                            helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                            disableButtons: sessionAttributes['disableButtons'],
                                            buttonsOpacity: sessionAttributes['buttonsOpacity']
                                        }
                                    }
                                }
                            });
                        }
                    }
                }
            }
        }

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

function checkSaying(start,end) {
    for(var i = 0; i < sayings.length; i++) {
        if(sayings[i][0].includes(start) && sayings[i][1].includes(end)) {
            return [i, sayingsEndOrder.indexOf(sayingsStartOrder[i])];
        }
    }
    return [-1,-1];
}

const SayingsIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SayingsIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'sayingButton');
    },
    handle(handlerInput) {
        let speakOutput = '';
        
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        const {intent} = handlerInput.requestEnvelope.request;     // Where slot information is
        
        if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
           ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
            if(sessionAttributes['phase'] === 2) {
                
                let sayingStart = "";
                let sayingEnd = "";
                let halfSayingIndex = "";
                if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                    sayingStart = Alexa.getSlotValue(handlerInput.requestEnvelope, 'sayingStart');
                    sayingEnd = Alexa.getSlotValue(handlerInput.requestEnvelope, 'sayingEnd');
                } else halfSayingIndex = halfSayingIndex + handlerInput.requestEnvelope.request.arguments[0];
                
                let directive = 0;
                const plural = sessionAttributes['plural'];
                if(sessionAttributes['sayingsTurn'] === 5){
                    speakOutput = handlerInput.t('SECOND_GAME_END')
                    speakOutput = speakOutput + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                } else {
                    if((sayingStart !== "") && (sayingEnd !== "")){
                        sessionAttributes['squareBorderColor' + (sessionAttributes['halfSayingIndex'] + 1)] = "";
                        sessionAttributes['halfSayingIndex'] = 10;
                        speakOutput = sayingStart + " " + sayingEnd + ". " + handlerInput.t('CORRECT_SAYING');
                        
                        const sayingIndex = checkSaying(sayingStart, sayingEnd);
                        if(sayingIndex[0] !== -1) {
                            if(sessionAttributes['squareLeft' + (sayingIndex[0] + 1)] !== "35vw") {
                                sessionAttributes['squareLeft' + (sayingIndex[0] + 1)] = "35vw";
                                sessionAttributes['squareRight' + (sayingIndex[1] + 1)] = "40vw";
                                sessionAttributes['sayingsTurn'] = sessionAttributes['sayingsTurn'] + 1;
                                if(sessionAttributes['sayingsTurn'] === 5) {
                                    sessionAttributes['sayingsOpacity'] = 0;
                                    sessionAttributes['sayingsAvatarOpacity'] = 1;
                                    let lastSpeech = handlerInput.t('SECOND_GAME_END');
                                    lastSpeech = lastSpeech + halfSecondPause + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                                    sessionAttributes['lastSpeech'] = lastSpeech;
                                    speakOutput = speakOutput + halfSecondPause + lastSpeech;
                                } else {
                                    speakOutput = speakOutput + halfSecondPause + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural];
                                }
                                sessionAttributes['lastSpeech'] = speakOutput;
                                directive = 1;
                            } else {
                                speakOutput = handlerInput.t('SAYING_NOT_AVAILABLE');
                            }
                        } else {
                            speakOutput = handlerInput.t('WRONG_SAYING')[plural];
                        }
                        
                    } else if (halfSayingIndex !== "") {    // Saying button pressed
                        halfSayingIndex = parseInt(halfSayingIndex) - 1;
                        
                        if(halfSayingIndex < 5) {   // First half selected
                            if(sessionAttributes['squareLeft' + (halfSayingIndex + 1)] !== "35vw") {
                                if(sessionAttributes['halfSayingIndex'] !== 10) {   // Another first half selected
                                    sessionAttributes['squareBorderColor' + (sessionAttributes['halfSayingIndex'] + 1)] = "";
                                }
                                sessionAttributes['halfSayingIndex'] = halfSayingIndex;
                                sessionAttributes['squareBorderColor' + (halfSayingIndex + 1)] = "black";
                                speakOutput = sayingsText[halfSayingIndex][0];
                                directive = 1;
                            }
                        } else {    // Second half selected
                            halfSayingIndex = halfSayingIndex - 5;
                            if(sessionAttributes['squareRight' + (halfSayingIndex + 1)] !== "40vw") {
                                if(sessionAttributes['halfSayingIndex'] !== 10) { // First half saying already selected
                                    sessionAttributes['squareBorderColor' + (sessionAttributes['halfSayingIndex'] + 1)] = "";
                                    directive = 1;
                                    speakOutput = sayingsText[halfSayingIndex][1];
                                    if(sayingsStartOrder[sessionAttributes['halfSayingIndex']] === sayingsEndOrder[halfSayingIndex]) {    // Saying correct
                                        speakOutput = speakOutput + ". " + handlerInput.t('CORRECT_SAYING');
                                        sessionAttributes['squareLeft' + (sessionAttributes['halfSayingIndex'] + 1)] = "35vw";
                                        sessionAttributes['squareRight' + (halfSayingIndex + 1)] = "40vw";
                                        sessionAttributes['sayingsTurn'] = sessionAttributes['sayingsTurn'] + 1;
                                        sessionAttributes['halfSayingIndex'] = 10;
                                        if(sessionAttributes['sayingsTurn'] === 5) {    // Game finished
                                            sessionAttributes['sayingsOpacity'] = 0;
                                            sessionAttributes['sayingsAvatarOpacity'] = 1;
                                            let lastSpeech = handlerInput.t('SECOND_GAME_END');
                                            lastSpeech = lastSpeech + halfSecondPause + handlerInput.t('ANSWER_OPTIONS_' + sessionAttributes['mode'])[plural];
                                            sessionAttributes['lastSpeech'] = lastSpeech;
                                            speakOutput = speakOutput + halfSecondPause + lastSpeech;
                                        } else {    // Game not finished
                                            speakOutput = speakOutput + halfSecondPause + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural];
                                        }
                                    } else { // Wrong saying parts
                                        sessionAttributes['halfSayingIndex'] = "";
                                        speakOutput = speakOutput + ". " + handlerInput.t('WRONG_SAYING')[plural];
                                    }
                                } else {    // First half saying not selected
                                    speakOutput = handlerInput.t('SELECT_FIRST_HALF')[plural];
                                }
                            }
                        }
                    }
                    if(directive === 1) {
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.sayingsDoc,
                            datasources: {
                                sayingsData: {
                                    type: 'object',
                                    properties: {
                                        title: handlerInput.t('SAYINGS_TITLE'),
                                        turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural],
                                        squareLeft1: sessionAttributes['squareLeft1'],
                                        squareLeft2: sessionAttributes['squareLeft2'],
                                        squareLeft3: sessionAttributes['squareLeft3'],
                                        squareLeft4: sessionAttributes['squareLeft4'],
                                        squareLeft5: sessionAttributes['squareLeft5'],
                                        squareRight1: sessionAttributes['squareRight1'],
                                        squareRight2: sessionAttributes['squareRight2'],
                                        squareRight3: sessionAttributes['squareRight3'],
                                        squareRight4: sessionAttributes['squareRight4'],
                                        squareRight5: sessionAttributes['squareRight5'],
                                        squareBorderColor1: sessionAttributes["squareBorderColor1"],
                                        squareBorderColor2: sessionAttributes["squareBorderColor2"],
                                        squareBorderColor3: sessionAttributes["squareBorderColor3"],
                                        squareBorderColor4: sessionAttributes["squareBorderColor4"],
                                        squareBorderColor5: sessionAttributes["squareBorderColor5"],
                                        halfSaying1Text: sayingsText[0][0],
                                        halfSaying2Text: sayingsText[1][0],
                                        halfSaying3Text: sayingsText[2][0],
                                        halfSaying4Text: sayingsText[3][0],
                                        halfSaying5Text: sayingsText[4][0],
                                        halfSaying6Text: sayingsText[0][1],
                                        halfSaying7Text: sayingsText[1][1],
                                        halfSaying8Text: sayingsText[2][1],
                                        halfSaying9Text: sayingsText[3][1],
                                        halfSaying10Text: sayingsText[4][1],
                                        startSayingBackground: Util.getS3PreSignedUrl("Media/startSayingBackground.png"),
                                        endSayingBackground: Util.getS3PreSignedUrl("Media/endSayingBackground.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                        endingOpacity: sessionAttributes['sayingsOpacity'],
                                        avatarOpacity: sessionAttributes['sayingsAvatarOpacity']
                                    }
                                }
                            }
                        });
                    }
                }
            } else {
                speakOutput = sessionAttributes['lastSpeech'];
            }
        }

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

const LabyrinthIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'LabyrinthIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'directionButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'answerButton');
    },
    handle(handlerInput) {
        let speakOutput = "";
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        
        if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
           ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
            let labTurn = sessionAttributes['labTurn'];
            let direction = "";
            let answer = "";
            if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') {
                direction = Alexa.getSlotValue(handlerInput.requestEnvelope, 'direction');
                answer = Alexa.getSlotValue(handlerInput.requestEnvelope, 'labAnswer');
            } else if(handlerInput.requestEnvelope.request.source.id === 'directionButton') {
                direction = handlerInput.requestEnvelope.request.arguments[0];
            } else {
                answer = handlerInput.requestEnvelope.request.arguments[0];
            }
            let avatar = Util.getS3PreSignedUrl("Media/avatar_happy.png");
            if(sessionAttributes['phase'] === 4) {
                let directive = 1;
                const plural = sessionAttributes['plural'];
                if(sessionAttributes['labEnded'] === 0) {
                    if(direction && sessionAttributes['onQuestion'] === 0) {
                        let labLeft = sessionAttributes['labLeftP' + labTurn];
                        let labTop = sessionAttributes['labTopP' + labTurn];
                        
                        const row = Math.round((parseFloat(labTop) - 25) / labCellHeight);
                        const col = Math.round((parseFloat(labLeft) - 18) / labCellWidth);
                        
                        let newLeft = labLeft;
                        let newTop = labTop;
                        let move = 1;
                        if(direction === 'arriba' && (laberinth[row][col][1]) === "1"){
                            newTop = parseFloat((parseFloat(labTop) - labCellHeight).toFixed(2)) + 'vh';
                        } else if(direction === 'abajo' && (laberinth[row][col][0]) === "1"){
                            newTop = parseFloat((parseFloat(labTop) + labCellHeight).toFixed(2)) + 'vh';
                        } else if(direction === 'izquierda' && (laberinth[row][col][3]) === "1") {
                            newLeft = parseFloat((parseFloat(labLeft) - labCellWidth).toFixed(2)) + 'vw';
                        } else if(direction === 'derecha' && (laberinth[row][col][2]) === "1") {
                            newLeft = parseFloat((parseFloat(labLeft) + labCellWidth).toFixed(2)) + 'vw';
                        } else {
                            speakOutput = speakOutput + handlerInput.t('WRONG_DIRECCION')[plural];
                            directive = 0;
                            move = 0;
                        }
                        
                        sessionAttributes['labTopP' + labTurn] = newTop;
                        sessionAttributes['labLeftP' + labTurn] = newLeft;
                        if((newLeft === labFinalPos[labTurn-1][0]) && (newTop === labFinalPos[labTurn-1][1])){
                            speakOutput = handlerInput.t('MONUMENT_REACHED', {group: nextPlayer[labTurn - 1], monument: handlerInput.t('GROUP_' + labTurn + '_ANSWER')[0]})[plural];
                            sessionAttributes['labP' + labTurn + 'end'] = 1;
                            sessionAttributes['moves'] = 1;
                        }
                        
                        if(sessionAttributes['moves'] === 1 && move === 1) {
                            sessionAttributes['p' + labTurn + 'BorderColor'] = "";
                            var aux = labTurn + 1;
                            var nextTurn = aux !== 5 ? aux : 1;
                            var i = 0;
                            while ((sessionAttributes['labP' + nextTurn + 'end'] === 1) && (i<4)) { // Find next player
                                aux = nextTurn + 1;
                                nextTurn = aux !== 5 ? aux : 1;
                                i++
                            }
                            if(i === 4) {
                                sessionAttributes['labEnded'] = 1;
                                sessionAttributes['p' + labTurn + 'BorderColor'] = "";
                                speakOutput = speakOutput + handlerInput.t('ALL_MONUMENTS_REACHED')[plural];
                                sessionAttributes['lastSpeech'] = handlerInput.t('MONUMENTS_REACHED_REPEAT')[plural];
                                sessionAttributes['searchEndOpacity'] = 0;
                                sessionAttributes['questionOpacity'] = 1;
                            } else {
                                sessionAttributes['labTurn'] = nextTurn;
                                sessionAttributes['moves'] = 5;
                                if(sessionAttributes['questions'] > 0) {  // Hacer pregunta al cambiar de turno
                                    sessionAttributes['onQuestion'] = 1;
                                    sessionAttributes['questionOpacity'] = 1;
                                    sessionAttributes['mapOpacity'] = 0.5;
                                    let text = halfSecondPause + handlerInput.t('PREPARE_FOR_QUESTION', { group: nextPlayer[nextTurn - 1] })[plural];
                                    text = text + halfSecondPause + handlerInput.t('GROUP_' + nextPlayer[nextTurn - 1] + '_QUESTION');
                                    text = text + handlerInput.t('LAB_Q_OPTIONS', {op1: handlerInput.t('GROUP_' + nextPlayer[nextTurn - 1] + '_OPTION_1'), 
                                                                                                 op2: handlerInput.t('GROUP_' + nextPlayer[nextTurn - 1] + '_OPTION_2'),
                                                                                                 op3: handlerInput.t('GROUP_' + nextPlayer[nextTurn - 1] + '_OPTION_3'),
                                                                                                 op4: handlerInput.t('GROUP_' + nextPlayer[nextTurn - 1] + '_OPTION_4')});
                                    text = text + handlerInput.t('ANSWER_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                                    
                                    sessionAttributes['lastSpeech'] = text;
                                    speakOutput = speakOutput + text;
                                    
                                    sessionAttributes['labBorderOp1'] = "";
                                    sessionAttributes['labBorderOp2'] = "";
                                    sessionAttributes['labBorderOp3'] = "";
                                    sessionAttributes['labBorderOp4'] = "";
                                } else {
                                    // TODO: QUITAR abajo
                                        
                                    sessionAttributes['labEnded'] = 1;
                                    speakOutput = speakOutput + handlerInput.t('ALL_MONUMENTS_REACHED')[plural];
                                    sessionAttributes['lastSpeech'] = handlerInput.t('MONUMENTS_REACHED_REPEAT')[plural];
                                    sessionAttributes['searchEndOpacity'] = 0;
                                    sessionAttributes['questionOpacity'] = 1;
                                    /********************/
                                    
                                    sessionAttributes['p' + nextTurn + 'BorderColor'] = "red";
                                    speakOutput = speakOutput + handlerInput.t('LAB_TURN', { group: nextPlayer[nextTurn - 1] })[plural];
                                }
                            }
                        } else {
                            sessionAttributes['moves'] = sessionAttributes['moves'] - move;
                        }
                    } else if(sessionAttributes['onQuestion'] === 1) {
                        if(answer) {
                            const possibleAnswer = handlerInput.t('GROUP_' + labTurn + '_ANSWER');
                            const correctAnswer = possibleAnswer.includes(answer);
                            if(correctAnswer){
                                speakOutput = handlerInput.t('CORRECT_ANSWER') + " " + handlerInput.t('LABYRINTH_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                                sessionAttributes['questionOpacity'] = 0;
                                sessionAttributes['mapOpacity'] = 1;
                                sessionAttributes['monument' + labTurn + 'Opacity'] = 1;
                                sessionAttributes['onQuestion'] = 0;
                                sessionAttributes['questions'] = sessionAttributes['questions'] - 1;
                                sessionAttributes['labBorderOp1'] = "";
                                sessionAttributes['labBorderOp2'] = "";
                                sessionAttributes['labBorderOp3'] = "";
                                sessionAttributes['labBorderOp4'] = "";
                                sessionAttributes['p' + labTurn + 'BorderColor'] = "red";
                            } else if(answer === handlerInput.t('GROUP_' + labTurn + '_OPTION_1')){
                                sessionAttributes['labBorderOp1'] = "red";
                                speakOutput = handlerInput.t('WRONG_ANSWER')[plural];
                                avatar = Util.getS3PreSignedUrl("Media/avatar_sad.png");
                            } else if(answer === handlerInput.t('GROUP_' + labTurn + '_OPTION_2')){
                                sessionAttributes['labBorderOp2'] = "red";
                                speakOutput = handlerInput.t('WRONG_ANSWER')[plural];
                                avatar = Util.getS3PreSignedUrl("Media/avatar_sad.png");
                            } else if(answer === handlerInput.t('GROUP_' + labTurn + '_OPTION_3')){
                                sessionAttributes['labBorderOp3'] = "red";
                                speakOutput = handlerInput.t('WRONG_ANSWER')[plural];
                                avatar = Util.getS3PreSignedUrl("Media/avatar_sad.png");
                            } else if(answer === handlerInput.t('GROUP_' + labTurn + '_OPTION_4')){
                                sessionAttributes['labBorderOp4'] = "red";
                                speakOutput = handlerInput.t('WRONG_ANSWER')[plural];
                                avatar = Util.getS3PreSignedUrl("Media/avatar_sad.png");
                            } else {
                                sessionAttributes['labBorderOp' + answer] = "red";
                                speakOutput = handlerInput.t('WRONG_ANSWER')[plural];
                                avatar = Util.getS3PreSignedUrl("Media/avatar_sad.png");
                            }
                        }
                        else {
                            speakOutput = handlerInput.t('WRONG_ANSWER_COMMAND');
                            directive = 0;
                        }
                    }
                } else {
                    speakOutput = handlerInput.t('MONUMENTS_REACHED_REPEAT')[plural];
                    directive = 0;
                }
                labTurn = sessionAttributes['labTurn'];
                if(directive === 1) {
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.labDoc,
                        datasources: {
                            labData: {
                                type: 'object',
                                properties: {
                                    p1: Util.getS3PreSignedUrl("Media/labAvatar1.png"),
                                    p2: Util.getS3PreSignedUrl("Media/labAvatar2.png"),
                                    p3: Util.getS3PreSignedUrl("Media/labAvatar3.png"),
                                    p4: Util.getS3PreSignedUrl("Media/labAvatar4.png"),
                                    p1Left: sessionAttributes['labLeftP1'],
                                    p2Left: sessionAttributes['labLeftP2'],
                                    p3Left: sessionAttributes['labLeftP3'],
                                    p4Left: sessionAttributes['labLeftP4'],
                                    p1Top: sessionAttributes['labTopP1'],
                                    p2Top: sessionAttributes['labTopP2'],
                                    p3Top: sessionAttributes['labTopP3'],
                                    p4Top: sessionAttributes['labTopP4'],
                                    question: handlerInput.t('GROUP_' + nextPlayer[labTurn - 1] + '_QUESTION'),
                                    qOption1: handlerInput.t('GROUP_' + nextPlayer[labTurn - 1] + '_OPTION_1'),
                                    qOption2: handlerInput.t('GROUP_' + nextPlayer[labTurn - 1] + '_OPTION_2'),
                                    qOption3: handlerInput.t('GROUP_' + nextPlayer[labTurn - 1] + '_OPTION_3'),
                                    qOption4: handlerInput.t('GROUP_' + nextPlayer[labTurn - 1] + '_OPTION_4'),
                                    aBorder1: sessionAttributes['labBorderOp1'],
                                    aBorder2: sessionAttributes['labBorderOp2'],
                                    aBorder3: sessionAttributes['labBorderOp3'],
                                    aBorder4: sessionAttributes['labBorderOp4'],
                                    moves: sessionAttributes['moves'],
                                    questionOpacity: sessionAttributes['questionOpacity'],
                                    mapOpacity: sessionAttributes['mapOpacity'],
                                    monument1Opacity: sessionAttributes['monument1Opacity'],
                                    monument2Opacity: sessionAttributes['monument2Opacity'],
                                    monument3Opacity: sessionAttributes['monument3Opacity'],
                                    monument4Opacity: sessionAttributes['monument4Opacity'],
                                    p1BorderColor: sessionAttributes['p1BorderColor'],
                                    p2BorderColor: sessionAttributes['p2BorderColor'],
                                    p3BorderColor: sessionAttributes['p3BorderColor'],
                                    p4BorderColor: sessionAttributes['p4BorderColor'],
                                    title: handlerInput.t('LAB_TITLE'),
                                    groupTurnText: handlerInput.t('TURN_TEXT', { group: nextPlayer[labTurn-1] })[plural],
                                    movesText: handlerInput.t('MOVES_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    monument1: Util.getS3PreSignedUrl("Media/monument_1.png"),
                                    monument2: Util.getS3PreSignedUrl("Media/monument_2.png"),
                                    monument3: Util.getS3PreSignedUrl("Media/monument_3.png"),
                                    monument4: Util.getS3PreSignedUrl("Media/monument_4.png"),
                                    labyrinth: Util.getS3PreSignedUrl("Media/labyrinth.png"),
                                    arrowUp: Util.getS3PreSignedUrl("Media/arrow_up.png"),
                                    arrowDown: Util.getS3PreSignedUrl("Media/arrow_down.png"),
                                    arrowLeft: Util.getS3PreSignedUrl("Media/arrow_left.png"),
                                    arrowRight: Util.getS3PreSignedUrl("Media/arrow_right.png"),
                                    labQuestionBackground: Util.getS3PreSignedUrl("Media/lab_question_background.png"),
                                    labOptionBackground: Util.getS3PreSignedUrl("Media/lab_option_background.png"),
                                    avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                    endOpacity: sessionAttributes['searchEndOpacity']
                                }
                            }
                        }
                    });
                }
            } else {
                speakOutput = sessionAttributes['lastSpeech'];
            }
        }

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

const AnswerIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AnswerIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'noButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'yesButton')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'continueButton');
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = "";
        if(((Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') && (sessionAttributes['mode'] !== 'TOUCH')) ||
           ((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') && (sessionAttributes['mode'] !== 'VOICE'))) {
            let answer = "";
            const plural = sessionAttributes['plural'];
            
            if (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest') answer = answer + Alexa.getSlotValue(handlerInput.requestEnvelope, 'answer');
            else answer = handlerInput.requestEnvelope.request.arguments[0];
            
            //const affirmations = handlerInput.t('YES');
            if(handlerInput.t('YES').includes(answer)) answer = 'yes';
            
            
            const lastIntent = sessionAttributes['lastIntent'];
            
            if((lastIntent === 'RestorePairs') && (sessionAttributes['askRestoreData'] === 'true')){
                sessionAttributes['askRestoreData'] = 'false';
                if(answer === 'yes') {
                    sessionAttributes['lastIntent'] = 'PairsIntent';
                    speakOutput = handlerInput.t('PAIRS_INSTRUCTIONS_' + sessionAttributes['mode']);
                    sessionAttributes['lastSpeech'] = speakOutput;
                    
                    if(sessionAttributes['lastCard1']) sessionAttributes["card" + sessionAttributes['lastCard1']] = "";
                    if(sessionAttributes['lastCard2']) sessionAttributes["card" + sessionAttributes['lastCard2']] = "";
                    sessionAttributes['lastCard1'] = "0";
                    sessionAttributes['lastCard2'] = "0";
                    
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: sessionAttributes["pairsDoc"],
                        datasources: {
                            pairsData: {
                                type: 'object',
                                properties: {
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    title: handlerInput.t('PAIRS_TITLE'),
                                    pairsText: "",
                                    triesText: handlerInput.t('TRIES'),
                                    tries: sessionAttributes['pairsTries'],
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    color1: sessionAttributes["card1"],
                                    color2: sessionAttributes["card2"],
                                    color3: sessionAttributes["card3"],
                                    color4: sessionAttributes["card4"],
                                    color5: sessionAttributes["card5"],
                                    color6: sessionAttributes["card6"],
                                    color7: sessionAttributes["card7"],
                                    color8: sessionAttributes["card8"],
                                    color9: sessionAttributes["card9"],
                                    color10: sessionAttributes["card10"],
                                    color11: sessionAttributes["card11"],
                                    color12: sessionAttributes["card12"],
                                    color13: sessionAttributes["card13"],
                                    color14: sessionAttributes["card14"],
                                    color15: sessionAttributes["card15"],
                                    color16: sessionAttributes["card16"],
                                    color17: sessionAttributes["card17"],
                                    color18: sessionAttributes["card18"],
                                    color19: sessionAttributes["card19"],
                                    color20: sessionAttributes["card20"],
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity']
                                }
                            }
                        }
                    });
                } else {
                    speakOutput = handlerInput.t('LEVEL_PAIRS_' + sessionAttributes['mode']);
                    sessionAttributes['lastIntent'] = 'ChooseLevel';
                    
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.pairsLevelDoc,
                        datasources: {
                            pairsLevelData: {
                                type: 'object',
                                properties: {
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    title: handlerInput.t('PAIRS_TITLE'),
                                    subTitle: handlerInput.t('PAIRS_SUB_TITLE'),
                                    easy: handlerInput.t('PAIRS_LEVEL_EASY'),
                                    medium: handlerInput.t('PAIRS_LEVEL_MEDIUM'),
                                    hard: handlerInput.t('PAIRS_LEVEL_HARD'),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity']
                                }
                            }
                        }
                    });
                }
                        
            } else if((lastIntent === 'RestoreSearch') && (sessionAttributes['askRestoreData'] === 'true')){
                sessionAttributes['askRestoreData'] = 'false';
                if(answer === 'yes') {
                    const numPlayers = sessionAttributes['sightseeingPlayers'];
                    if(numPlayers > 1) { sessionAttributes['plural'] = 1; }
                    else { sessionAttributes['plural'] = 0; }
                    if(numPlayers === 1) nextPlayer = ["1","1","1","1"];
                    else if(numPlayers === 2) nextPlayer = ["1","2","1","2"];
                    else if(numPlayers === 4) nextPlayer = ["1","2","3","4"];
                    
                    let plural = sessionAttributes['plural'];
                    
                    if(sessionAttributes['phase'] === 1){
                        sessionAttributes['lastIntent'] = 'ImagesIntent';
                        const turn = sessionAttributes['imagesTurn'];
                        speakOutput = handlerInput.t('FIRST_GAME_START')[plural] + halfSecondPause + handlerInput.t('IMAGE_HELP_' + sessionAttributes['mode'])[plural];
                        let text = handlerInput.t('PREPARE_FOR_DESCRIPTION', { group: nextPlayer[turn - 1] })[sessionAttributes['plural']];
                        text = text + handlerInput.t('IMAGE_DESCRIPTION_' + turn) + (handlerInput.t('IMAGE_INSTRUCTIONS_' + sessionAttributes['mode'])[sessionAttributes['plural']]);
                        sessionAttributes['lastSpeech'] = text;
                        speakOutput = speakOutput + halfSecondPause + text;
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.imagesDoc,
                            datasources: {
                                imagesData: {
                                    type: 'object',
                                    properties: {
                                        title: handlerInput.t('IMAGES_TITLE'),
                                        turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['imagesTurn'] - 1] })[plural],
                                        image1: Util.getS3PreSignedUrl("Media/Option" + turn + "-0.png"),
                                        image2: Util.getS3PreSignedUrl("Media/Option" + turn + "-1.png"),
                                        image3: Util.getS3PreSignedUrl("Media/Option" + turn + "-2.png"),
                                        image4: Util.getS3PreSignedUrl("Media/Option" + turn + "-3.png"),
                                        endingOpacity: sessionAttributes['imagesOpacity'],
                                        frameColor1: "",
                                        frameColor2: "",
                                        frameColor3: "",
                                        frameColor4: "",
                                        repeat_image: Util.getS3PreSignedUrl("Media/repeat_image.png"),
                                        avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else if(sessionAttributes['phase'] === 2) {
                        sessionAttributes['lastIntent'] = 'SayingsIntent';
                        speakOutput = handlerInput.t('SECOND_GAME_START') + halfSecondPause + handlerInput.t('SAYINGS_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                        speakOutput = speakOutput + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural]; // TODO
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.sayingsDoc,
                            datasources: {
                                sayingsData: {
                                    type: 'object',
                                    properties: {
                                        title: handlerInput.t('SAYINGS_TITLE'),
                                        turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural],
                                        squareLeft1: sessionAttributes['squareLeft1'],
                                        squareLeft2: sessionAttributes['squareLeft2'],
                                        squareLeft3: sessionAttributes['squareLeft3'],
                                        squareLeft4: sessionAttributes['squareLeft4'],
                                        squareLeft5: sessionAttributes['squareLeft5'],
                                        squareRight1: sessionAttributes['squareRight1'],
                                        squareRight2: sessionAttributes['squareRight2'],
                                        squareRight3: sessionAttributes['squareRight3'],
                                        squareRight4: sessionAttributes['squareRight4'],
                                        squareRight5: sessionAttributes['squareRight5'],
                                        squareBorderColor1: sessionAttributes["squareBorderColor1"],
                                        squareBorderColor2: sessionAttributes["squareBorderColor2"],
                                        squareBorderColor3: sessionAttributes["squareBorderColor3"],
                                        squareBorderColor4: sessionAttributes["squareBorderColor4"],
                                        squareBorderColor5: sessionAttributes["squareBorderColor5"],
                                        halfSaying1Text: sayingsText[0][0],
                                        halfSaying2Text: sayingsText[1][0],
                                        halfSaying3Text: sayingsText[2][0],
                                        halfSaying4Text: sayingsText[3][0],
                                        halfSaying5Text: sayingsText[4][0],
                                        halfSaying6Text: sayingsText[0][1],
                                        halfSaying7Text: sayingsText[1][1],
                                        halfSaying8Text: sayingsText[2][1],
                                        halfSaying9Text: sayingsText[3][1],
                                        halfSaying10Text: sayingsText[4][1],
                                        startSayingBackground: Util.getS3PreSignedUrl("Media/startSayingBackground.png"),
                                        endSayingBackground: Util.getS3PreSignedUrl("Media/endSayingBackground.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                        endingOpacity: sessionAttributes['sayingsOpacity'],
                                        avatarOpacity: sessionAttributes['sayingsAvatarOpacity']
                                    }
                                }
                            }
                        });
                    } else if(sessionAttributes['phase'] === 3) {
                        sessionAttributes["lastIntent"] = "PuzzleIntent";
                        speakOutput = handlerInput.t('THIRD_GAME_START');
                        let lastSpeech = handlerInput.t('THIRD_GAME_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                        lastSpeech = lastSpeech + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1] })[plural];
                        speakOutput = speakOutput + lastSpeech;
                        sessionAttributes['lastSpeech'] = lastSpeech;
                        
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.puzzleDoc,
                            datasources: {
                                puzzleData: {
                                    type: 'object',
                                    properties: {
                                        op1: sessionAttributes['puzzleImOp1'],
                                        op2: sessionAttributes['puzzleImOp2'],
                                        op3: sessionAttributes['puzzleImOp3'],
                                        op4: sessionAttributes['puzzleImOp4'], 
                                        op5: sessionAttributes['puzzleImOp5'],
                                        op6: sessionAttributes['puzzleImOp6'], 
                                        op7: sessionAttributes['puzzleImOp7'], 
                                        op8: sessionAttributes['puzzleImOp8'],
                                        op9: sessionAttributes['puzzlePlOp1'],
                                        op10: sessionAttributes['puzzlePlOp2'],
                                        op11: sessionAttributes['puzzlePlOp3'],
                                        op12: sessionAttributes['puzzlePlOp4'], 
                                        op13: sessionAttributes['puzzlePlOp5'],
                                        op14: sessionAttributes['puzzlePlOp6'], 
                                        op15: sessionAttributes['puzzlePlOp7'], 
                                        op16: sessionAttributes['puzzlePlOp8'],
                                        border1: sessionAttributes['puzzleImBorder1'],
                                        border2: sessionAttributes['puzzleImborder2'],
                                        border3: sessionAttributes['puzzleImborder3'],
                                        border4: sessionAttributes['puzzleImborder4'], 
                                        border5: sessionAttributes['puzzleImborder5'],
                                        border6: sessionAttributes['puzzleImborder6'], 
                                        border7: sessionAttributes['puzzleImborder7'], 
                                        border8: sessionAttributes['puzzleImborder8'],
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else if(sessionAttributes['phase'] === 4) {
                        sessionAttributes['lastIntent'] = "LabyrinthIntent";
                        
                        // TODO: Ver donde falla al continuar partida en laberinto
                        const group = nextPlayer[sessionAttributes['labTurn'] - 1];
                        if(sessionAttributes['onQuestion'] === 1) {
                            speakOutput = handlerInput.t('FOURTH_GAME_START')[plural];
                            speakOutput = speakOutput + ' ' + handlerInput.t('PREPARE_FOR_QUESTION', { group: group })[plural] + halfSecondPause;
                            var lastSpeech = handlerInput.t('TURN', { group: nextPlayer[group - 1] })[plural] + handlerInput.t('GROUP_' + group + '_QUESTION');
                            lastSpeech = lastSpeech + handlerInput.t('LAB_Q_OPTIONS', {op1: handlerInput.t('GROUP_' + group + '_OPTION_1'), 
                                                                                         op2: handlerInput.t('GROUP_' + group + '_OPTION_2'),
                                                                                         op3: handlerInput.t('GROUP_' + group + '_OPTION_3'),
                                                                                         op4: handlerInput.t('GROUP_' + group + '_OPTION_4')});
                            lastSpeech = lastSpeech + handlerInput.t('ANSWER_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                            speakOutput = speakOutput + lastSpeech;
                            sessionAttributes['lastSpeech'] = lastSpeech;
                        } else {
                            speakOutput = handlerInput.t('LABYRINTH_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                            speakOutput = speakOutput + halfSecondPause + handlerInput.t('TURN', { group: group })[plural];
                        }
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.labDoc,
                            datasources: {
                                labData: {
                                    type: 'object',
                                    properties: {
                                        p1: Util.getS3PreSignedUrl("Media/labAvatar1.png"),
                                        p2: Util.getS3PreSignedUrl("Media/labAvatar2.png"),
                                        p3: Util.getS3PreSignedUrl("Media/labAvatar3.png"),
                                        p4: Util.getS3PreSignedUrl("Media/labAvatar4.png"),
                                        p1Left: sessionAttributes['labLeftP1'],
                                        p2Left: sessionAttributes['labLeftP2'],
                                        p3Left: sessionAttributes['labLeftP3'],
                                        p4Left: sessionAttributes['labLeftP4'],
                                        p1Top: sessionAttributes['labTopP1'],
                                        p2Top: sessionAttributes['labTopP2'],
                                        p3Top: sessionAttributes['labTopP3'],
                                        p4Top: sessionAttributes['labTopP4'],
                                        question: handlerInput.t('GROUP_' + group + '_QUESTION'),
                                        qOption1: handlerInput.t('GROUP_' + group + '_OPTION_1'),
                                        qOption2: handlerInput.t('GROUP_' + group + '_OPTION_2'),
                                        qOption3: handlerInput.t('GROUP_' + group + '_OPTION_3'),
                                        qOption4: handlerInput.t('GROUP_' + group + '_OPTION_4'),
                                        aBorder1: sessionAttributes['labBorderOp1'],
                                        aBorder2: sessionAttributes['labBorderOp2'],
                                        aBorder3: sessionAttributes['labBorderOp3'],
                                        aBorder4: sessionAttributes['labBorderOp4'],
                                        moves: sessionAttributes['moves'],
                                        questionOpacity: sessionAttributes['questionOpacity'],
                                        mapOpacity: sessionAttributes['mapOpacity'],
                                        monument1Opacity: sessionAttributes['monument1Opacity'],
                                        monument2Opacity: sessionAttributes['monument2Opacity'],
                                        monument3Opacity: sessionAttributes['monument3Opacity'],
                                        monument4Opacity: sessionAttributes['monument4Opacity'],
                                        p1BorderColor: sessionAttributes['p1BorderColor'],
                                        p2BorderColor: sessionAttributes['p2BorderColor'],
                                        p3BorderColor: sessionAttributes['p3BorderColor'],
                                        p4BorderColor: sessionAttributes['p4BorderColor'],
                                        title: handlerInput.t('LAB_TITLE'),
                                        groupTurnText: handlerInput.t('TURN_TEXT', { group: nextPlayer[/*sessionAttributes['labTurn']*/group-1] })[plural],
                                        movesText: handlerInput.t('MOVES_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        monument1: Util.getS3PreSignedUrl("Media/monument_1.png"),
                                        monument2: Util.getS3PreSignedUrl("Media/monument_2.png"),
                                        monument3: Util.getS3PreSignedUrl("Media/monument_3.png"),
                                        monument4: Util.getS3PreSignedUrl("Media/monument_4.png"),
                                        labyrinth: Util.getS3PreSignedUrl("Media/labyrinth.png"),
                                        arrowUp: Util.getS3PreSignedUrl("Media/arrow_up.png"),
                                        arrowDown: Util.getS3PreSignedUrl("Media/arrow_down.png"),
                                        arrowLeft: Util.getS3PreSignedUrl("Media/arrow_left.png"),
                                        arrowRight: Util.getS3PreSignedUrl("Media/arrow_right.png"),
                                        labQuestionBackground: Util.getS3PreSignedUrl("Media/lab_question_background.png"),
                                        labOptionBackground: Util.getS3PreSignedUrl("Media/lab_option_background.png"),
                                        avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                        endOpacity: sessionAttributes['searchEndOpacity']
                                    }
                                }
                            }
                        });
                    }
                    
                } else {
                    sessionAttributes['lastIntent'] = "ChoosePlayers";
                    speakOutput = handlerInput.t('CHOOSE_PLAYERS_QUESTION') + handlerInput.t('CHOOSE_PLAYERS_INSTRUCTIONS_' + sessionAttributes['mode']);
                    sessionAttributes['lastSpeech'] = speakOutput;
                    
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.choosePlayersDoc,
                        datasources: {
                            choosePlayersData: {
                                type: 'object',
                                properties: {
                                    title: handlerInput.t('GAME_3'),
                                    subTitle: handlerInput.t('CHOOSE_PLAYERS_QUESTION'),
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity']
                                }
                            }
                        }
                    });
                }
            } else if(lastIntent === "MapSearchIntent") {
                if(answer === 'yes') {
                    sessionAttributes['lastIntent'] = 'ImagesIntent';
                    sessionAttributes['phase'] = 1;
                    sessionAttributes['imagesTurn'] = 1;
                    speakOutput = (handlerInput.t('FIRST_GAME_START')[plural]) + halfSecondPause + handlerInput.t('IMAGE_HELP_' + sessionAttributes['mode'])[plural];
                    let text = handlerInput.t('PREPARE_FOR_DESCRIPTION', { group: nextPlayer[0] })[plural];
                    text = text + handlerInput.t('IMAGE_DESCRIPTION_1') + (handlerInput.t('IMAGE_INSTRUCTIONS_' + sessionAttributes['mode'])[plural]);
                    sessionAttributes['lastSpeech'] = text;
                    speakOutput = speakOutput + halfSecondPause + text;
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.imagesDoc,
                        datasources: {
                            imagesData: {
                                type: 'object',
                                properties: {
                                    title: handlerInput.t('IMAGES_TITLE'),
                                    turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['imagesTurn'] - 1] })[plural],
                                    image1: Util.getS3PreSignedUrl("Media/Option1-0.png"),
                                    image2: Util.getS3PreSignedUrl("Media/Option1-1.png"),
                                    image3: Util.getS3PreSignedUrl("Media/Option1-2.png"),
                                    image4: Util.getS3PreSignedUrl("Media/Option1-3.png"),
                                    endingOpacity: sessionAttributes['imagesOpacity'],
                                    frameColor1: "",
                                    frameColor2: "",
                                    frameColor3: "",
                                    frameColor4: "",
                                    repeat_image: Util.getS3PreSignedUrl("Media/repeat_image.png"),
                                    avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity']
                                }
                            }
                        }
                    });
                } else {
                    speakOutput = handlerInput.t('NO_HELP')
                }
            } else if(lastIntent === "ImagesIntent") { 
                if(answer === 'yes') {
                    if(sessionAttributes['imagesTurn'] > 4) {
                        sessionAttributes['lastIntent'] = "Park";
                        speakOutput = handlerInput.t('HELP_WITH_HOMEWORK');
                        sessionAttributes['lastSpeech'] = speakOutput;
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.parkDoc,
                            datasources: {
                                parkData: {
                                    type: 'object',
                                    properties: {
                                        parkImage: Util.getS3PreSignedUrl("Media/park.png"),
                                        avatar1: Util.getS3PreSignedUrl("Media/kid.png"),
                                        avatar2: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else {
                        speakOutput = handlerInput.t('IMAGES_NOT_ENDED')[plural] + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['imagesTurn'] - 1] }); // TODO
                    }
                } else {
                    speakOutput = handlerInput.t('NO_PARK')
                }
            } else if(lastIntent === "Park") {
                if(answer === 'yes') {
                    sessionAttributes['lastIntent'] = 'SayingsIntent';
                    sessionAttributes['phase'] = 2;
                    speakOutput = handlerInput.t('SECOND_GAME_START') + halfSecondPause + handlerInput.t('SAYINGS_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                    sessionAttributes['lastSpeech'] = handlerInput.t('SAYINGS_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                    speakOutput = speakOutput + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural]; // TODO
                    handlerInput.responseBuilder.addDirective({
                        type: 'Alexa.Presentation.APL.RenderDocument',
                        version: '1.1',
                        document: constants.APL.sayingsDoc,
                        datasources: {
                            sayingsData: {
                                type: 'object',
                                properties: {
                                    title: handlerInput.t('SAYINGS_TITLE'),
                                    turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural],
                                    squareLeft1: sessionAttributes['squareLeft1'],
                                    squareLeft2: sessionAttributes['squareLeft2'],
                                    squareLeft3: sessionAttributes['squareLeft3'],
                                    squareLeft4: sessionAttributes['squareLeft4'],
                                    squareLeft5: sessionAttributes['squareLeft5'],
                                    squareRight1: sessionAttributes['squareRight1'],
                                    squareRight2: sessionAttributes['squareRight2'],
                                    squareRight3: sessionAttributes['squareRight3'],
                                    squareRight4: sessionAttributes['squareRight4'],
                                    squareRight5: sessionAttributes['squareRight5'],
                                    squareBorderColor1: sessionAttributes["squareBorderColor1"],
                                    squareBorderColor2: sessionAttributes["squareBorderColor2"],
                                    squareBorderColor3: sessionAttributes["squareBorderColor3"],
                                    squareBorderColor4: sessionAttributes["squareBorderColor4"],
                                    squareBorderColor5: sessionAttributes["squareBorderColor5"],
                                    halfSaying1Text: sayingsText[0][0],
                                    halfSaying2Text: sayingsText[1][0],
                                    halfSaying3Text: sayingsText[2][0],
                                    halfSaying4Text: sayingsText[3][0],
                                    halfSaying5Text: sayingsText[4][0],
                                    halfSaying6Text: sayingsText[0][1],
                                    halfSaying7Text: sayingsText[1][1],
                                    halfSaying8Text: sayingsText[2][1],
                                    halfSaying9Text: sayingsText[3][1],
                                    halfSaying10Text: sayingsText[4][1],
                                    startSayingBackground: Util.getS3PreSignedUrl("Media/startSayingBackground.png"),
                                    endSayingBackground: Util.getS3PreSignedUrl("Media/endSayingBackground.png"),
                                    exitButtonText: handlerInput.t('EXIT_TEXT'),
                                    continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                    helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                    disableButtons: sessionAttributes['disableButtons'],
                                    buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                    endingOpacity: sessionAttributes['sayingsOpacity'],
                                    avatarOpacity: sessionAttributes['sayingsAvatarOpacity']
                                }
                            }
                        }
                    });
                } else {
                    speakOutput = handlerInput.t('NO_HOMEWORK');
                }
            } else if(lastIntent === "SayingsIntent") {
                if(answer === 'yes') {
                    if(sessionAttributes['sayingsTurn'] === 5) {
                        sessionAttributes["lastIntent"] = "PuzzleIntent";
                        sessionAttributes['phase'] = 3;
                        
                        speakOutput = handlerInput.t('THIRD_GAME_START');
                        let lastSpeech = handlerInput.t('THIRD_GAME_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                        lastSpeech = lastSpeech + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1]})[plural];
                        speakOutput = speakOutput + lastSpeech;
                        sessionAttributes['lastSpeech'] = lastSpeech;
                        
                        initializePuzzle(sessionAttributes);
                        
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.puzzleDoc,
                            datasources: {
                                puzzleData: {
                                    type: 'object',
                                    properties: {
                                        op1: sessionAttributes['puzzleImOp1'],
                                        op2: sessionAttributes['puzzleImOp2'],
                                        op3: sessionAttributes['puzzleImOp3'],
                                        op4: sessionAttributes['puzzleImOp4'], 
                                        op5: sessionAttributes['puzzleImOp5'],
                                        op6: sessionAttributes['puzzleImOp6'], 
                                        op7: sessionAttributes['puzzleImOp7'], 
                                        op8: sessionAttributes['puzzleImOp8'],
                                        op9: sessionAttributes['puzzlePlOp1'],
                                        op10: sessionAttributes['puzzlePlOp2'],
                                        op11: sessionAttributes['puzzlePlOp3'],
                                        op12: sessionAttributes['puzzlePlOp4'], 
                                        op13: sessionAttributes['puzzlePlOp5'],
                                        op14: sessionAttributes['puzzlePlOp6'], 
                                        op15: sessionAttributes['puzzlePlOp7'], 
                                        op16: sessionAttributes['puzzlePlOp8'],
                                        border1: sessionAttributes['puzzleImBorder1'],
                                        border2: sessionAttributes['puzzleImborder2'],
                                        border3: sessionAttributes['puzzleImborder3'],
                                        border4: sessionAttributes['puzzleImborder4'], 
                                        border5: sessionAttributes['puzzleImborder5'],
                                        border6: sessionAttributes['puzzleImborder6'], 
                                        border7: sessionAttributes['puzzleImborder7'], 
                                        border8: sessionAttributes['puzzleImborder8'],
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity']
                                    }
                                }
                            }
                        });
                    } else {
                        speakOutput = handlerInput.t('SAYINGS_NOT_ENDED')[plural] + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] }); //TODO
                    }
                } else {
                    if(sessionAttributes['sayingsTurn'] === 5) {
                        speakOutput = handlerInput.t('SECOND_GAME_END'); // TODO
                    }
                }
            } else if(lastIntent === "PuzzleIntent") {
                if(answer === 'yes') {
                    if(sessionAttributes['puzzleCorrect'] === 8) {
                        sessionAttributes['phase'] = 4;
                        sessionAttributes['lastIntent'] = "LabyrinthIntent";
                        initializeLabyrinth(sessionAttributes);
                        speakOutput = handlerInput.t('FOURTH_GAME_START')[plural] + twoSecondsPause;
                        speakOutput =  speakOutput = handlerInput.t('PREPARE_FOR_QUESTION', { group: nextPlayer[0] })[plural] + halfSecondPause;
                        let lastSpeech = handlerInput.t('GROUP_1_QUESTION');
                        lastSpeech = lastSpeech + handlerInput.t('LAB_Q_OPTIONS', {op1: handlerInput.t('GROUP_1_OPTION_1'), 
                                                                       op2: handlerInput.t('GROUP_1_OPTION_2'),
                                                                       op3: handlerInput.t('GROUP_1_OPTION_3'),
                                                                       op4: handlerInput.t('GROUP_1_OPTION_4')});
                        lastSpeech = lastSpeech + handlerInput.t('ANSWER_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                        sessionAttributes['lastSpeech'] = lastSpeech;
                        speakOutput = speakOutput + lastSpeech;
                        
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.labDoc,
                            datasources: {
                                labData: {
                                    type: 'object',
                                    properties: {
                                        p1: Util.getS3PreSignedUrl("Media/labAvatar1.png"),
                                        p2: Util.getS3PreSignedUrl("Media/labAvatar2.png"),
                                        p3: Util.getS3PreSignedUrl("Media/labAvatar3.png"),
                                        p4: Util.getS3PreSignedUrl("Media/labAvatar4.png"),
                                        p1Left: sessionAttributes['labLeftP1'],
                                        p2Left: sessionAttributes['labLeftP2'],
                                        p3Left: sessionAttributes['labLeftP3'],
                                        p4Left: sessionAttributes['labLeftP4'],
                                        p1Top: sessionAttributes['labTopP1'],
                                        p2Top: sessionAttributes['labTopP2'],
                                        p3Top: sessionAttributes['labTopP3'],
                                        p4Top: sessionAttributes['labTopP4'],
                                        question: handlerInput.t('GROUP_1_QUESTION'),
                                        qOption1: handlerInput.t('GROUP_1_OPTION_1'),
                                        qOption2: handlerInput.t('GROUP_1_OPTION_2'),
                                        qOption3: handlerInput.t('GROUP_1_OPTION_3'),
                                        qOption4: handlerInput.t('GROUP_1_OPTION_4'),
                                        aBorder1: sessionAttributes['labBorderOp1'],
                                        aBorder2: sessionAttributes['labBorderOp2'],
                                        aBorder3: sessionAttributes['labBorderOp3'],
                                        aBorder4: sessionAttributes['labBorderOp4'],
                                        moves: sessionAttributes['moves'],
                                        questionOpacity: sessionAttributes['questionOpacity'],
                                        mapOpacity: sessionAttributes['mapOpacity'],
                                        monument1Opacity: sessionAttributes['monument1Opacity'],
                                        monument2Opacity: sessionAttributes['monument2Opacity'],
                                        monument3Opacity: sessionAttributes['monument3Opacity'],
                                        monument4Opacity: sessionAttributes['monument4Opacity'],
                                        p1BorderColor: sessionAttributes['p1BorderColor'],
                                        p2BorderColor: sessionAttributes['p2BorderColor'],
                                        p3BorderColor: sessionAttributes['p3BorderColor'],
                                        p4BorderColor: sessionAttributes['p4BorderColor'],
                                        title: handlerInput.t('LAB_TITLE'),
                                        groupTurnText: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['labTurn'] - 1] })[plural],
                                        movesText: handlerInput.t('MOVES_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        monument1: Util.getS3PreSignedUrl("Media/monument_1.png"),
                                        monument2: Util.getS3PreSignedUrl("Media/monument_2.png"),
                                        monument3: Util.getS3PreSignedUrl("Media/monument_3.png"),
                                        monument4: Util.getS3PreSignedUrl("Media/monument_4.png"),
                                        labyrinth: Util.getS3PreSignedUrl("Media/labyrinth.png"),
                                        arrowUp: Util.getS3PreSignedUrl("Media/arrow_up.png"),
                                        arrowDown: Util.getS3PreSignedUrl("Media/arrow_down.png"),
                                        arrowLeft: Util.getS3PreSignedUrl("Media/arrow_left.png"),
                                        arrowRight: Util.getS3PreSignedUrl("Media/arrow_right.png"),
                                        labQuestionBackground: Util.getS3PreSignedUrl("Media/lab_question_background.png"),
                                        labOptionBackground: Util.getS3PreSignedUrl("Media/lab_option_background.png"),
                                        avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                        endOpacity: sessionAttributes['searchEndOpacity']
                                    }
                                }
                            }
                        });
                    } else {
                        speakOutput = handlerInput.t('PUZZLE_NOT_ENDED')[plural] + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1] }); // TODO
                    }
                } else {
                    if(sessionAttributes['puzzleCorrect'] === 8) {
                        speakOutput = handlerInput.t('PUZZLE_ENDED_INSIST')[plural]; // TODO
                    }
                }
            } else if(lastIntent === "LabyrinthIntent") {
                if(answer === 'yes') {
                    if(sessionAttributes['labEnded'] === 0) {
                        speakOutput = handlerInput.t('LAB_NOT_ENDED') + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['labTurn'] - 1] });
                    } else {
                        initializeMapSearch(handlerInput);
                        sessionAttributes['mapSearchEnd'] = 1;
                        speakOutput = handlerInput.t('GOODBYE')[plural] + oneSecondPause + handlerInput.t('EXIT_GAME_' + sessionAttributes['mode'])[plural];
                        handlerInput.responseBuilder.addDirective({
                            type: 'Alexa.Presentation.APL.RenderDocument',
                            version: '1.1',
                            document: constants.APL.finDoc,
                            datasources: {
                                sightseeingData: {
                                    type: 'object',
                                    properties: {
                                        parkImage: Util.getS3PreSignedUrl("Media/park.png"),
                                        welcomeText: handlerInput.t('GOODBYE_TEXT'),
                                        exitButtonText: handlerInput.t('EXIT_TEXT'),
                                        helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                        disableButtons: sessionAttributes['disableButtons'],
                                        buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                        continueButtonOpacity: 0
                                    }
                                }
                            }
                        });
                    }
                } else {
                    if(sessionAttributes['labEnded'] === 1) {
                        speakOutput = handlerInput.t('EXIT_GAME_' + sessionAttributes['mode'])[plural];
                    }
                }
            }
        }
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

const ChooseMinigameIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'ChooseMinigameIntent';
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        let speakOutput = "";
        
        //if((Alexa.getRequestType(handlerInput.requestEnvelope) !== 'IntentRequest') || (sessionAttributes['mode'] !== 'TOUCH')) {
            const minigame = Alexa.getSlotValue(handlerInput.requestEnvelope, 'minigame');
            const plural = sessionAttributes['plural'];
            
            if(minigame === "reconocer imagenes") { // Descripciones
                sessionAttributes['phase'] = 1;
                sessionAttributes['lastIntent'] = 'ImagesIntent';
                sessionAttributes['labEnded'] = 0;
                
                initializeImageDescription(sessionAttributes);
                
                speakOutput = (handlerInput.t('FIRST_GAME_START')[plural]) + halfSecondPause + handlerInput.t('IMAGE_HELP_' + sessionAttributes['mode'])[plural];
                let text = handlerInput.t('PREPARE_FOR_DESCRIPTION', { group: nextPlayer[0] })[plural];
                text = text + handlerInput.t('IMAGE_DESCRIPTION_1') + (handlerInput.t('IMAGE_INSTRUCTIONS_' + sessionAttributes['mode'])[plural]);
                sessionAttributes['lastSpeech'] = text;
                speakOutput = speakOutput + halfSecondPause + text;
                    
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.imagesDoc,
                    datasources: {
                        imagesData: {
                            type: 'object',
                            properties: {
                                title: handlerInput.t('IMAGES_TITLE'),
                                turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['imagesTurn'] - 1] })[plural],
                                image1: Util.getS3PreSignedUrl("Media/Option1-0.png"),
                                image2: Util.getS3PreSignedUrl("Media/Option1-1.png"),
                                image3: Util.getS3PreSignedUrl("Media/Option1-2.png"),
                                image4: Util.getS3PreSignedUrl("Media/Option1-3.png"),
                                endingOpacity: sessionAttributes['imagesOpacity'],
                                frameColor1: "",
                                frameColor2: "",
                                frameColor3: "",
                                frameColor4: "",
                                repeat_image: Util.getS3PreSignedUrl("Media/repeat_image.png"),
                                avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            } else if(minigame === "montar el mapa") {
                // Puzzle
                sessionAttributes['phase'] = 3;
                sessionAttributes['lastIntent'] = 'PuzzleIntent';
                sessionAttributes['labEnded'] = 0;
                
                initializePuzzle(sessionAttributes);
                
                speakOutput = handlerInput.t('THIRD_GAME_START');
                let lastSpeech = handlerInput.t('THIRD_GAME_INSTRUCTIONS_' + sessionAttributes['mode'])[plural]
                lastSpeech = lastSpeech + handlerInput.t('TURN', { group: nextPlayer[sessionAttributes['puzzleTurn'] - 1] })[plural];
                speakOutput = speakOutput + lastSpeech;
                sessionAttributes['lastSpeech'] = lastSpeech;
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.puzzleDoc,
                    datasources: {
                        puzzleData: {
                            type: 'object',
                            properties: {
                                op1: sessionAttributes['puzzleImOp1'],
                                op2: sessionAttributes['puzzleImOp2'],
                                op3: sessionAttributes['puzzleImOp3'],
                                op4: sessionAttributes['puzzleImOp4'], 
                                op5: sessionAttributes['puzzleImOp5'],
                                op6: sessionAttributes['puzzleImOp6'], 
                                op7: sessionAttributes['puzzleImOp7'], 
                                op8: sessionAttributes['puzzleImOp8'],
                                op9: sessionAttributes['puzzlePlOp1'],
                                op10: sessionAttributes['puzzlePlOp2'],
                                op11: sessionAttributes['puzzlePlOp3'],
                                op12: sessionAttributes['puzzlePlOp4'], 
                                op13: sessionAttributes['puzzlePlOp5'],
                                op14: sessionAttributes['puzzlePlOp6'], 
                                op15: sessionAttributes['puzzlePlOp7'], 
                                op16: sessionAttributes['puzzlePlOp8'],
                                border1: sessionAttributes['puzzleImBorder1'],
                                border2: sessionAttributes['puzzleImborder2'],
                                border3: sessionAttributes['puzzleImborder3'],
                                border4: sessionAttributes['puzzleImborder4'], 
                                border5: sessionAttributes['puzzleImborder5'],
                                border6: sessionAttributes['puzzleImborder6'], 
                                border7: sessionAttributes['puzzleImborder7'], 
                                border8: sessionAttributes['puzzleImborder8'],
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity']
                            }
                        }
                    }
                });
            } else if(minigame === "deberes") { // Refranes
                sessionAttributes['phase'] = 2;
                sessionAttributes['lastIntent'] = 'SayingsIntent';
                sessionAttributes['labEnded'] = 0;
                
                initializeSayings(handlerInput);
                speakOutput =  handlerInput.t('SECOND_GAME_START') + halfSecondPause + handlerInput.t('SAYINGS_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                speakOutput = speakOutput + handlerInput.t('TURN', { group: nextPlayer[0] })[plural];
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.sayingsDoc,
                    datasources: {
                        sayingsData: {
                            type: 'object',
                            properties: {
                                title: handlerInput.t('SAYINGS_TITLE'),
                                turn: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['sayingsTurn'] - 1] })[plural],
                                squareLeft1: sessionAttributes['squareLeft1'],
                                squareLeft2: sessionAttributes['squareLeft2'],
                                squareLeft3: sessionAttributes['squareLeft3'],
                                squareLeft4: sessionAttributes['squareLeft4'],
                                squareLeft5: sessionAttributes['squareLeft5'],
                                squareRight1: sessionAttributes['squareRight1'],
                                squareRight2: sessionAttributes['squareRight2'],
                                squareRight3: sessionAttributes['squareRight3'],
                                squareRight4: sessionAttributes['squareRight4'],
                                squareRight5: sessionAttributes['squareRight5'],
                                squareBorderColor1: sessionAttributes["squareBorderColor1"],
                                squareBorderColor2: sessionAttributes["squareBorderColor2"],
                                squareBorderColor3: sessionAttributes["squareBorderColor3"],
                                squareBorderColor4: sessionAttributes["squareBorderColor4"],
                                squareBorderColor5: sessionAttributes["squareBorderColor5"],
                                halfSaying1Text: sayingsText[0][0],
                                halfSaying2Text: sayingsText[1][0],
                                halfSaying3Text: sayingsText[2][0],
                                halfSaying4Text: sayingsText[3][0],
                                halfSaying5Text: sayingsText[4][0],
                                halfSaying6Text: sayingsText[0][1],
                                halfSaying7Text: sayingsText[1][1],
                                halfSaying8Text: sayingsText[2][1],
                                halfSaying9Text: sayingsText[3][1],
                                halfSaying10Text: sayingsText[4][1],
                                startSayingBackground: Util.getS3PreSignedUrl("Media/startSayingBackground.png"),
                                endSayingBackground: Util.getS3PreSignedUrl("Media/endSayingBackground.png"),
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                endingOpacity: sessionAttributes['sayingsOpacity'],
                                avatarOpacity: sessionAttributes['sayingsAvatarOpacity']
                            }
                        }
                    }
                });
            } else if(minigame === "hacer turismo") {   // Visit monuments
                sessionAttributes['phase'] = 4;
                sessionAttributes['lastIntent'] = "LabyrinthIntent";
                
                initializeLabyrinth(sessionAttributes);
                
                speakOutput = handlerInput.t('FOURTH_GAME_START')[plural] + twoSecondsPause;
                speakOutput = handlerInput.t('PREPARE_FOR_QUESTION', { group: nextPlayer[0] })[plural] + halfSecondPause;
                let lastSpeech = handlerInput.t('GROUP_1_QUESTION');
                lastSpeech = lastSpeech + handlerInput.t('LAB_Q_OPTIONS', {op1: handlerInput.t('GROUP_1_OPTION_1'), 
                                                                             op2: handlerInput.t('GROUP_1_OPTION_2'),
                                                                             op3: handlerInput.t('GROUP_1_OPTION_3'),
                                                                             op4: handlerInput.t('GROUP_1_OPTION_4')});
                lastSpeech = lastSpeech + handlerInput.t('ANSWER_INSTRUCTIONS_' + sessionAttributes['mode'])[plural];
                sessionAttributes['lastSpeech'] = lastSpeech;
                speakOutput = speakOutput + lastSpeech;
                
                handlerInput.responseBuilder.addDirective({
                    type: 'Alexa.Presentation.APL.RenderDocument',
                    version: '1.1',
                    document: constants.APL.labDoc,
                    datasources: {
                        labData: {
                            type: 'object',
                            properties: {
                                p1: Util.getS3PreSignedUrl("Media/labAvatar1.png"),
                                p2: Util.getS3PreSignedUrl("Media/labAvatar2.png"),
                                p3: Util.getS3PreSignedUrl("Media/labAvatar3.png"),
                                p4: Util.getS3PreSignedUrl("Media/labAvatar4.png"),
                                p1Left: sessionAttributes['labLeftP1'],
                                p2Left: sessionAttributes['labLeftP2'],
                                p3Left: sessionAttributes['labLeftP3'],
                                p4Left: sessionAttributes['labLeftP4'],
                                p1Top: sessionAttributes['labTopP1'],
                                p2Top: sessionAttributes['labTopP2'],
                                p3Top: sessionAttributes['labTopP3'],
                                p4Top: sessionAttributes['labTopP4'],
                                question: handlerInput.t('GROUP_1_QUESTION'),
                                qOption1: handlerInput.t('GROUP_1_OPTION_1'),
                                qOption2: handlerInput.t('GROUP_1_OPTION_2'),
                                qOption3: handlerInput.t('GROUP_1_OPTION_3'),
                                qOption4: handlerInput.t('GROUP_1_OPTION_4'),
                                aBorder1: sessionAttributes['labBorderOp1'],
                                aBorder2: sessionAttributes['labBorderOp2'],
                                aBorder3: sessionAttributes['labBorderOp3'],
                                aBorder4: sessionAttributes['labBorderOp4'],
                                moves: sessionAttributes['moves'],
                                questionOpacity: sessionAttributes['questionOpacity'],
                                mapOpacity: sessionAttributes['mapOpacity'],
                                monument1Opacity: sessionAttributes['monument1Opacity'],
                                monument2Opacity: sessionAttributes['monument2Opacity'],
                                monument3Opacity: sessionAttributes['monument3Opacity'],
                                monument4Opacity: sessionAttributes['monument4Opacity'],
                                p1BorderColor: sessionAttributes['p1BorderColor'],
                                p2BorderColor: sessionAttributes['p2BorderColor'],
                                p3BorderColor: sessionAttributes['p3BorderColor'],
                                p4BorderColor: sessionAttributes['p4BorderColor'],
                                title: handlerInput.t('LAB_TITLE'),
                                groupTurnText: handlerInput.t('TURN_TEXT', { group: nextPlayer[sessionAttributes['labTurn'] - 1] })[plural],
                                movesText: handlerInput.t('MOVES_TEXT'),
                                helpIcon: Util.getS3PreSignedUrl("Media/help_icon.png"),
                                monument1: Util.getS3PreSignedUrl("Media/monument_1.png"),
                                monument2: Util.getS3PreSignedUrl("Media/monument_2.png"),
                                monument3: Util.getS3PreSignedUrl("Media/monument_3.png"),
                                monument4: Util.getS3PreSignedUrl("Media/monument_4.png"),
                                labyrinth: Util.getS3PreSignedUrl("Media/labyrinth.png"),
                                arrowUp: Util.getS3PreSignedUrl("Media/arrow_up.png"),
                                arrowDown: Util.getS3PreSignedUrl("Media/arrow_down.png"),
                                arrowLeft: Util.getS3PreSignedUrl("Media/arrow_left.png"),
                                arrowRight: Util.getS3PreSignedUrl("Media/arrow_right.png"),
                                labQuestionBackground: Util.getS3PreSignedUrl("Media/lab_question_background.png"),
                                labOptionBackground: Util.getS3PreSignedUrl("Media/lab_option_background.png"),
                                avatar: Util.getS3PreSignedUrl("Media/avatar_happy.png"),
                                exitButtonText: handlerInput.t('EXIT_TEXT'),
                                continueButtonText: handlerInput.t('CONTINUE_TEXT'),
                                disableButtons: sessionAttributes['disableButtons'],
                                buttonsOpacity: sessionAttributes['buttonsOpacity'],
                                endOpacity: sessionAttributes['searchEndOpacity']
                            }
                        }
                    }
                });
            }
        //}
        
        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return (Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent')
            || (Alexa.getRequestType(handlerInput.requestEnvelope) === 'Alexa.Presentation.APL.UserEvent'
            && handlerInput.requestEnvelope.request.source.id === 'helpButton');
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();

        return handlerInput.responseBuilder
            .speak(sessionAttributes['lastSpeech'] + oneMinuteOfSilence)
            .reprompt(sessionAttributes['lastSpeech'] + oneMinuteOfSilence)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Saliendo!';

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
        if(sessionAttributes['lastIntent'] === 'LaunchIntent') {
            // TODO: nombre usuario
        }
        const speakOutput = handlerInput.t('FALLBACK_HANDLER_TEXT');

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = debug + handlerInput.t('ERROR_HANDLER_TEXT');
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput + oneMinuteOfSilence)
            .reprompt(speakOutput + oneMinuteOfSilence)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .withPersistenceAdapter(ddbPersistenceAdapter)
    .addRequestHandlers(
        IdentificationRequestHandler,
        LaunchRequestHandler,
        GoBackIntentHandler,
        InteractionModeIntentHandler,
        CatalogIntentHandler,
        PairsLevelIntentHandler,
        SportsIntentHandler,
        LabyrinthIntentHandler,
        ImagesRequestHandler,
        SayingsIntentHandler,
        AnswerIntentHandler,
        ChooseMinigameIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler)
    .addErrorHandlers(
        ErrorHandler)
    .addRequestInterceptors(
        interceptors.LocalizationInterceptor,
        interceptors.LoggingRequestInterceptor,
        interceptors.LoadAttributesRequestInterceptor)
    .addResponseInterceptors(
        interceptors.LoggingResponseInterceptor,
        interceptors.SaveAttributesResponseInterceptor)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();